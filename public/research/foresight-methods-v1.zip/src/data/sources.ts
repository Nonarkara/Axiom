/**
 * The source register.
 *
 * CONSERVATION LAW OF THIS BUILD:
 *   every rendered number equals a sourced claim.
 *   No fact reaches the screen without { value, source, url, tier }.
 *
 * The tier vocabulary is not invented here. It is lifted from §7 of the
 * Economic Clusters V2 paper, which already declares its own source tiers and
 * states plainly that the four-axis scores are "analytical judgments by the
 * author" and that the High=3 … Very Low=0.5 encoding is "a presentation
 * device". Preserving that distinction on screen is the whole point: a
 * dashboard's easiest failure is to render a judgment in the same typeface as a
 * measurement and let the reader assume both were counted.
 */

export type Tier =
  | 'official' // issuing agency / national statistics
  | 'secondary' // official data transcribed via an aggregator
  | 'estimate' // bank, consultancy or commercial market research
  | 'projection' // forward-looking; not a realised outcome
  | 'judgment' // the author's analytical score, not a measurement
  | 'derived' // added by this console; NOT present in the source documents
  | 'external'; // corroboration this console added from a source outside the two papers

export interface Source {
  id: string;
  label: string;
  url: string;
  tier: Tier;
  /** Shown in the tier chip's tooltip. */
  note?: string;
}

export const TIER_MEANING: Record<Tier, string> = {
  official: 'Official statistics or the issuing agency.',
  secondary: 'Official data transcribed via a secondary aggregator.',
  estimate: 'Bank, consultancy or commercial market research. Read as an estimate.',
  projection: 'Forward-looking projection, not a realised outcome.',
  judgment: "The author's analytical judgment, not a measured value.",
  derived: 'Added by this console for navigation. Not stated in the source documents.',
  external:
    'Corroboration added by this console from a trusted source outside the two papers.',
};

const list: Source[] = [
  // ── The two source documents ────────────────────────────────────────────
  {
    id: 'docA',
    label:
      'Thiengburanathum, P. (2026). The Anchor Strategy v1.1 — Thailand in the Multipolar Transition. Future Signals · Strategic Foresight Series.',
    url: 'https://forsight.craft.me/6S8F26TZcMyf6z',
    tier: 'judgment',
    note: 'Strategic foresight report. Trajectories are bracket scenarios, not forecasts.',
  },
  {
    id: 'docB',
    label:
      "Thailand's Economic Clusters: Value, Growth, Local Contribution, and Sovereignty — V2 (July 2026). PMU-A.",
    url: 'https://forsight.craft.me/jlRBiYvhyZ2msI',
    tier: 'judgment',
    note: 'Four-axis scores are the author’s analytical judgments synthesising the cited evidence.',
  },

  // ── Official statistics and issuing agencies ────────────────────────────
  {
    id: 'nesdc-gpp',
    label: 'NESDC. Gross Regional and Provincial Product (GPP).',
    url: 'https://www.nesdc.go.th/en/info/gross-regional-and-provincial-product-gpp/',
    tier: 'official',
    note: 'Region-by-region shares anchored to the 2019 edition; 2024 nominal anchors from the 2024 provincial report.',
  },
  {
    id: 'oie-production',
    label: 'Office of Industrial Economics (2025). Production situation of the manufacturing sector, June 2025.',
    url: 'https://www.oie.go.th/assets/portals/1/files/industrial_article/ProductionSituation_June2025_en.pdf',
    tier: 'official',
  },
  {
    id: 'oie-annual',
    label:
      'Office of Industrial Economics (2026). Report on the industrial economics status 2024 and outlook for 2025.',
    url: 'https://www.oie.go.th/assets/portals/1/files/monthly_report/anualreport2024_outlookfor2025.pdf',
    tier: 'official',
    note: 'Manufacturing sub-sector splits are reconstructed from MPI weights and trade data — indicative, not official.',
  },
  {
    id: 'ceic-debt',
    label: 'CEIC Data (2026). Thailand household debt: % of nominal GDP (Bank of Thailand series).',
    url: 'https://www.ceicdata.com/en/indicator/thailand/household-debt--of-nominal-gdp',
    tier: 'official',
  },
  {
    id: 'bp-exports',
    label: 'Bangkok Post (2025, Jan 23). Ministry says 2024 exports surpassed target.',
    url: 'https://www.bangkokpost.com/business/general/2946257/ministry-says-2024-exports-surpassed-target',
    tier: 'official',
    note: 'Ministry of Commerce / Trade Policy and Strategy Office figures as reported.',
  },
  {
    id: 'bp-autos',
    label: 'Bangkok Post (2025, Jan 28). Thailand car production down 20% in 2024.',
    url: 'https://www.bangkokpost.com/business/motoring/2949236/thailand-car-production-down-20-in-2024',
    tier: 'official',
    note: 'Federation of Thai Industries figures as reported.',
  },
  {
    id: 'bp-tourism',
    label: 'Bangkok Post (2026, Jan 5). 32.9m foreigners visited in 2025.',
    url: 'https://www.bangkokpost.com/thailand/general/3168779/329m-foreigners-visited-in-2025',
    tier: 'official',
    note: 'Ministry of Tourism and Sports figures as reported.',
  },
  {
    id: 'bp-steel',
    label: 'Bangkok Post (2024, Jun 7). Concerns over decline in steel consumption.',
    url: 'https://www.bangkokpost.com/business/general/2806529/concerns-over-decline-in-steel-consumption',
    tier: 'official',
  },
  {
    id: 'nation-gdp',
    label: "Nation Thailand (2026). Thailand's economy defies forecasts with 2.4% growth in 2025.",
    url: 'https://www.nationthailand.com/business/investment/40062584',
    tier: 'official',
  },
  {
    id: 'nation-tourism',
    label: 'Nation Thailand (2026). Thailand tourism slips in 2025 despite domestic growth.',
    url: 'https://www.nationthailand.com/news/general/40060629',
    tier: 'official',
  },
  {
    id: 'nation-kitchen',
    label:
      "Nation Thailand (2025). Thailand serves up record-breaking showcase as 'kitchen to the world' ambitions take centre stage.",
    url: 'https://www.nationthailand.com/business/economy/40050528',
    tier: 'official',
  },
  {
    id: 'tbn-wd',
    label: "Thailand Business News (2024). Thailand approves Western Digital's 23.5 billion baht project.",
    url: 'https://www.thailand-business-news.com/companies/158470-thailand-approves-western-digitals-23-5-billion-baht-project',
    tier: 'official',
    note: 'Board of Investment approval as reported.',
  },

  // ── Official data via secondary aggregation ─────────────────────────────
  {
    id: 'tge-services',
    label: 'TheGlobalEconomy (2025). Thailand: Share of services.',
    url: 'https://www.theglobaleconomy.com/thailand/share_of_services/',
    tier: 'secondary',
    note: 'NESDC blocks automated access; services is ~59% on a value-added basis and ~61.6% by the residual method — always cite the method.',
  },
  {
    id: 'tge-manufacturing',
    label: 'TheGlobalEconomy (2025). Thailand: Share of manufacturing.',
    url: 'https://www.theglobaleconomy.com/Thailand/Share_of_manufacturing/',
    tier: 'secondary',
    note: 'NESDC national accounts transcribed via a secondary aggregator.',
  },

  // ── Bank, consultancy and commercial research ───────────────────────────
  {
    id: 'krungsri',
    label: 'Krungsri Research (2025). Thailand industry outlook 2025–2027. Bank of Ayudhya.',
    url: 'https://www.krungsri.com/en/research/industry/summary-outlook/thailand-industry-outlook-summary-2025-2027',
    tier: 'estimate',
  },
  {
    id: 'krasia',
    label: 'KrASIA (2025). What naphtha shortage? China extends petrochemicals lead.',
    url: 'https://kr-asia.com/what-naphtha-shortage-china-extends-petrochemicals-lead-amid-us-iran-conflict',
    tier: 'estimate',
  },
  {
    id: 'maverick-ev',
    label: 'Maverick Consulting Group (2026, Apr 2). Thailand EV policy 2026: oil shock, Chinese dominance, and the road ahead.',
    url: 'https://www.mcg-asia.com/featured-insights/thailand-ev-policy-2026',
    tier: 'estimate',
    note: 'EV share ranges from ~70% (BEV-only) to ~85% (all EV sales) depending on scope; the direction is unambiguous.',
  },
  {
    id: 'usasean-ev',
    label: "US-ASEAN Business Council (2025, Sep). Thailand's EV market surges toward 100,000 sales in 2025.",
    url: 'https://www.usasean.org/article/thailands-ev-market-surges-toward-100000-sales-2025',
    tier: 'estimate',
  },
  {
    id: 'gmi-wellness',
    label: 'Global Market Insights (2025). ASEAN medical and wellness tourism market, 2024–2034.',
    url: 'https://www.gminsights.com/industry-analysis/asean-medical-and-wellness-tourism-market',
    tier: 'estimate',
    note: 'Commercial market research used where no official series exists.',
  },
  {
    id: 'gdch-dc',
    label:
      "Global Data Center Hub (2025). Why are AWS, Google, and TikTok pouring billions into Thailand's data center market?",
    url: 'https://www.globaldatacenterhub.com/p/why-are-hyperscalers-betting-billions',
    tier: 'estimate',
    note: 'Industry tracker used where no official series exists.',
  },

  // ── Forward-looking ─────────────────────────────────────────────────────
  {
    id: 'nation-futurefood',
    label: "Nation Thailand (2025). Thailand ranked the world's 12th future food exporter.",
    url: 'https://www.nationthailand.com/news/general/40039983',
    tier: 'projection',
    note: 'The ฿500bn 2027 export figure is a target, not a realised outcome.',
  },
  {
    id: 'investor-2026',
    label: 'The Investor (2026). Thailand revises up 2026 growth outlook.',
    url: 'https://theinvestor.vn/thailand-revises-up-2026-growth-outlook-d18432.html',
    tier: 'projection',
  },

  // ── Outside check: corroboration the console added, not cited by either
  //    paper. All tiered 'external' so a reader can never mistake them for the
  //    author's own evidence base. ─────────────────────────────────────────
  {
    id: 'wb-mpo',
    label: 'World Bank. Macro Poverty Outlook — Thailand (2026 edition).',
    url: 'https://thedocs.worldbank.org/en/doc/c6aceb75bed03729ef4ff9404dd7f125-0500012021/related/mpo-tha.pdf',
    tier: 'external',
    note: 'World Bank country projections. Vintages during 2025–26 ranged 1.3–1.6% for 2026 growth.',
  },
  {
    id: 'wb-digital',
    label: "World Bank (2025, July). Thailand's digital future key to boosting growth (press release).",
    url: 'https://www.worldbank.org/en/news/press-release/2025/07/03/thailand-s-digital-future-key-to-boosting-growth',
    tier: 'external',
  },
  {
    id: 'wb-65plus',
    label: 'World Bank Open Data. Population ages 65 and above (% of total) — Thailand.',
    url: 'https://data.worldbank.org/indicator/SP.POP.65UP.TO.ZS?locations=TH',
    tier: 'external',
  },
  {
    id: 'un-demography',
    label: 'United Nations in Thailand. Demographic change in Thailand: how planners can prepare.',
    url: 'https://thailand.un.org/en/96303-thailand-economic-focus-demographic-change-thailand-how-planners-can-prepare-future',
    tier: 'external',
  },
  {
    id: 'nxpo-rd',
    label: 'NXPO. Thailand gross domestic expenditure on R&D and the 2%-of-GDP target.',
    url: 'https://www.nxpo.or.th/th/en/17125/',
    tier: 'external',
    note: 'NXPO is the state science, research and innovation policy council — the target is its own.',
  },
  {
    id: 'imd-wcr',
    label: 'IMD World Competitiveness Ranking 2025, as reported by Nation Thailand.',
    url: 'https://www.nationthailand.com/business/economy/40067591',
    tier: 'external',
  },
  {
    id: 'imd-digital',
    label: 'IMD World Digital Competitiveness Ranking 2025.',
    url: 'https://www.imd.org/centers/wcc/world-competitiveness-center/rankings/world-digital-competitiveness-ranking/',
    tier: 'external',
  },
  {
    id: 'tge-agriculture',
    label: 'TheGlobalEconomy. Thailand: share of agriculture.',
    url: 'https://www.theglobaleconomy.com/Thailand/Share_of_agriculture/',
    tier: 'secondary',
    note: "The paper cites its GDP-composition block to TGE's services and manufacturing pages; this chip links the agriculture series itself.",
  },
  {
    id: 'poon-rg',
    label: 'ResearchGate. Poon Thiengburanathum — publication record.',
    url: 'https://www.researchgate.net/profile/Poon-Thiengburanathum',
    tier: 'external',
  },

  // ── The literature check (§10): peer-reviewed and institutional studies the
  //    argument can be read against. Same rule as the outside check — tiered
  //    'external', cited by neither paper, every DOI resolved before commit. ──
  {
    id: 'kuik-2008',
    label:
      'Kuik, C.-C. (2008). The Essence of Hedging: Malaysia and Singapore’s Response to a Rising China. Contemporary Southeast Asia 30(2).',
    url: 'https://doi.org/10.1355/cs30-2a',
    tier: 'external',
    note: 'Hedging as deliberate small-state posture — the academic form of §01’s unaligned claim.',
  },
  {
    id: 'ciorciari-2010',
    label:
      'Ciorciari, J. D. (2010). The Limits of Alignment: Southeast Asia and the Great Powers since 1975. Georgetown University Press.',
    url: 'https://doi.org/10.1353/book681',
    tier: 'external',
    note: 'Four decades of Southeast Asian cases behind the alignment-diversity the 35%/25% rules codify.',
  },
  {
    id: 'farrell-newman-2019',
    label:
      'Farrell, H. & Newman, A. L. (2019). Weaponized Interdependence: How Global Economic Networks Shape State Coercion. International Security 44(1).',
    url: 'https://doi.org/10.1162/isec_a_00351',
    tier: 'external',
    note: 'The hub-and-chokepoint mechanism underneath trajectory α and the Technology Sovereignty Doctrine.',
  },
  {
    id: 'goh-2013',
    label:
      'Goh, E. (2013). The Struggle for Order: Hegemony, Hierarchy, and Transition in the Contemporary International System. Oxford University Press.',
    url: 'https://doi.org/10.1093/acprof:oso/9780199599363.001.0001',
    tier: 'external',
    note: 'The counter-reading: negotiated hierarchy rather than a side-choosing balance.',
  },
  {
    id: 'nye-1990',
    label: 'Nye, J. S. (1990). Soft Power. Foreign Policy (80).',
    url: 'https://doi.org/10.2307/1148580',
    tier: 'external',
    note: 'The concept Pillar 4 monetizes.',
  },
  {
    id: 'undp-2007',
    label:
      'UNDP (2007). Thailand Human Development Report 2007: Sufficiency Economy and Human Development.',
    url: 'https://hdr.undp.org/content/thailand-human-development-report-2007',
    tier: 'external',
    note: 'The most authoritative statement of the self-immunity condition the Sovereign Foundation builds on.',
  },
  {
    id: 'mongsawad-2010',
    label:
      'Mongsawad, P. (2010). The Philosophy of the Sufficiency Economy: A Contribution to the Theory of Development. Asia-Pacific Development Journal 17(1).',
    url: 'https://doi.org/10.18356/02bd5fb3-en',
    tier: 'external',
    note: 'SEP formalised as development theory — the Foundation’s academic lineage.',
  },
  {
    id: 'knodel-2009',
    label:
      'Knodel, J. (2009). Older Persons in Thailand: A Demographic, Social and Economic Profile. Ageing International 34(1–3).',
    url: 'https://doi.org/10.1007/s12126-009-9025-8',
    tier: 'external',
    note: 'The demographic schedule Pillar 5 answers.',
  },
  {
    id: 'spp-cmu',
    label: 'School of Public Policy, Chiang Mai University. Faculty profile: Assoc. Prof. Poon Thiengburanathum, PhD.',
    url: 'https://spp.cmu.ac.th/member/poon-thiengburanathum/',
    tier: 'external',
  },

  // ── Key documents referenced by the timeline (§15) ───────────────────
  {
    id: 'asean-charter',
    label: 'ASEAN. The ASEAN Charter (2007).',
    url: 'https://asean.org/our-community/asean-charter/',
    tier: 'external',
    note: 'The legal foundation of the ASEAN-Anchored Diplomacy pillar.',
  },
  {
    id: 'rcep',
    label: 'ASEAN Secretariat. Regional Comprehensive Economic Partnership Agreement (signed November 2020).',
    url: 'https://rcepsec.org/legal-text/',
    tier: 'external',
    note: 'The 15-party framework the strategy reads as a hedge on US-China split.',
  },
  {
    id: 'imf-1997',
    label: 'Government of Thailand / IMF. Letter of Intent and Memorandum of Economic Policies, August 1997.',
    url: 'https://www.imf.org/external/np/loi/082798.htm',
    tier: 'external',
    note: 'The 1997 condition under which sufficiency economy became official doctrine.',
  },
  {
    id: 'boi-eseb',
    label: 'Thailand Board of Investment. Eastern Special Development Zone (Eastern Seaboard, established 1982; EEC Act 2018).',
    url: 'https://www.boi.go.th/index.php?page=eastern-seaboard',
    tier: 'official',
    note: 'The 1982 plan that built the EEC platform; the 2018 Act that gives it legal standing.',
  },
  {
    id: 'un-unescap-1974',
    label: 'King Bhumibol Adulyadej (1974). Address to Kasetsart University graduates, 18 July 1974.',
    url: 'https://www.un.org/en/desa/sufficiency-economy-thailand',
    tier: 'external',
    note: 'The first public articulation of sufficiency economy philosophy.',
  },
  {
    id: 'asean-2025',
    label: 'ASEAN. ASEAN 2025: Forging Ahead Together (master plan).',
    url: 'https://asean.org/our-communities/asean-2025/',
    tier: 'external',
    note: 'The community-building agenda the strategy assumes continues.',
  },
  {
    id: 'wb-fdi',
    label: 'World Bank Open Data. Foreign direct investment, net inflows (% of GDP) — Thailand.',
    url: 'https://data.worldbank.org/indicator/BX.KLT.DINV.WD.GD.ZS?locations=TH',
    tier: 'external',
    note: 'The series behind the FDI sparkline on the brief.',
  },
  {
    id: 'krungsri-ev',
    label: 'Krungsri Research. Thailand EV market and outlook 2015–2024 (compiled).',
    url: 'https://www.krungsri.com/en/research/industry/summary-outlook/thailand-industry-outlook-summary-2025-2027',
    tier: 'estimate',
    note: 'The series behind the EV-share sparkline. Bank of Ayudhya research.',
  },

  // ── The literature check (§10): peer-reviewed and institutional studies the
  //    argument can be read against. Same rule as the outside check — tiered
  //    'external', cited by neither paper, every DOI resolved before commit. ──
  {
    id: 'amsden-2001',
    label:
      'Amsden, A. H. (2001). The Rise of "The Rest": Challenges to the West from Late-Industrializing Economies. Oxford University Press.',
    url: 'https://doi.org/10.1093/0195139690.001.0001',
    tier: 'external',
    note: 'Late-industrialization as a discipline of technology transfer with domestic learning — the doctrine behind the Specialized Industrial Niches pillar.',
  },
  {
    id: 'pempel-2010',
    label:
      'Pempel, T. J. (2010). Soft Balancing, Hedging, and Institutional Darwinism: The Economic-Security Link in East Asia. Asian Survey 50(6).',
    url: 'https://doi.org/10.1525/as.2010.50.6.1080',
    tier: 'external',
    note: 'Hedging as a portfolio of reversible bets, not a single posture — refines the §01 decision matrix.',
  },
  {
    id: 'doner-2009',
    label:
      'Doner, R. F., Ritchie, B. K. & Slater, D. (2009). The Politics of Uneven Development: Thailand\'s Economic Growth in Comparative Perspective. Cambridge University Press.',
    url: 'https://doi.org/10.1017/cbo9780511819186',
    tier: 'external',
    note: 'Thailand\'s coalition-driven growth produced durable spatial concentration — the political-economy reading of the 16.5× GPP gap.',
  },
  {
    id: 'acharya-2014',
    label:
      'Acharya, A. (2014). Constructing a Security Community in Southeast Asia (3rd ed.). Routledge.',
    url: 'https://doi.org/10.4324/9781315796673',
    tier: 'external',
    note: 'ASEAN as a habit-formation order — the academic lineage of the ASEAN-Anchored Diplomacy pillar.',
  },
  {
    id: 'pasuk-baker-2009',
    label:
      'Phongpaichit, P. & Baker, C. (2009). A History of Thailand (2nd ed.). Cambridge University Press.',
    url: 'https://doi.org/10.1017/cbo9781139194877',
    tier: 'external',
    note: 'The longer-cycle context: the Bangkok-Isaan gap is a recurring pattern, now an international exposure.',
  },
];

export const SOURCES: Record<string, Source> = Object.fromEntries(
  list.map((s) => [s.id, s]),
);

export const SOURCE_LIST = list;

/** A number, bound to the claim that supports it. Nothing renders without one. */
export interface FactRecord {
  /** Rendered verbatim — pre-formatted so units, currency and precision stay as published. */
  value: string;
  /** Key into SOURCES. */
  src: string;
  /**
   * Raise the tier above the source's own where the specific figure is weaker
   * than the outlet — e.g. an official body publishing a target.
   */
  tier?: Tier;
  /** One-line statement of what this figure does not say. */
  caveat?: string;
}

export function tierOf(f: FactRecord): Tier {
  return f.tier ?? SOURCES[f.src].tier;
}
