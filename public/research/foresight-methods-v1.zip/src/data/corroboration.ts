import type { FactRecord } from './sources.ts';

/**
 * The outside check. None of these figures appears in either paper — they are
 * corroboration this console added, every one tiered 'external' so a reader can
 * separate the author's evidence from ours. Each group ends with the claim in
 * the papers that the outside data supports or complicates.
 */
export interface CheckGroup {
  id: string;
  title: string;
  facts: Array<FactRecord & { label: string }>;
  reading: string;
  paperClaim: string;
}

export const OUTSIDE_CHECK: CheckGroup[] = [
  {
    id: 'growth',
    title: 'Growth',
    facts: [
      {
        label: 'World Bank growth projection, 2026',
        value: '1.3–1.6%',
        src: 'wb-mpo',
        caveat: 'Range across 2025–26 forecast vintages; each cut cited weak trade, household debt and slow tourism recovery.',
      },
      {
        label: 'Potential growth, past decade',
        value: '3% → 2.6–2.7%',
        src: 'wb-digital',
        caveat: 'The decline is structural — technology, ageing, shrinking fiscal space — not cyclical.',
      },
    ],
    reading:
      'The World Bank sees Thailand slower than the papers assume, and says the ceiling itself is falling. It names the same escape routes the cluster paper does: creative economy, agri-business, sustainable tourism, green manufacturing, digital services.',
    paperClaim: 'Clusters V2: a services-and-manufacturing hybrid in a low-growth equilibrium.',
  },
  {
    id: 'demography',
    title: 'Demography',
    facts: [
      {
        label: 'Population aged 65+, 2024',
        value: '14.3%',
        src: 'wb-65plus',
      },
      {
        label: 'Working-age population, 2010–2040',
        value: '−10%',
        src: 'un-demography',
        caveat: 'World Bank forecast of the contraction, cited by the UN country team.',
      },
    ],
    reading:
      'Thailand is ageing before it is rich. The workforce that would staff every pillar is shrinking on a known schedule — which is why the strategy makes human capital a pillar rather than an afterthought, and why Vietnam’s demographic pattern does not transfer.',
    paperClaim: 'Anchor Strategy: Pillar 5 exists because no talent means no anchor.',
  },
  {
    id: 'innovation',
    title: 'Innovation capacity',
    facts: [
      {
        label: 'R&D spend, 2023',
        value: '0.94% of GDP',
        src: 'nxpo-rd',
        caveat: 'Down from 1.21% in 2021; the fall came mostly from private investment.',
      },
      {
        label: 'The state’s own target, 2027',
        value: '2% of GDP',
        src: 'nxpo-rd',
        tier: 'projection',
      },
    ],
    reading:
      'The country spends less than half its own R&D target, and the trend runs the wrong way. The industrial bets in these papers — advanced packaging, compound semiconductors, battery recycling — all assume research capacity that must still be funded into existence.',
    paperClaim: 'Anchor Strategy: specialised industrial niches need capability, not announcements.',
  },
  {
    id: 'competitiveness',
    title: 'Competitiveness',
    facts: [
      {
        label: 'IMD World Competitiveness 2025',
        value: '30th of 69',
        src: 'imd-wcr',
        caveat: 'Down five places in one year; government efficiency fell 24th → 32nd.',
      },
      {
        label: 'IMD Digital Competitiveness 2025',
        value: '38th of 69',
        src: 'imd-digital',
        caveat: 'Score rose 65.5 → 69.0 while the rank fell — Thailand advances, the world moves faster.',
      },
    ],
    reading:
      'Independent rankings agree with the papers’ quiet warning: the binding constraint is institutional, not industrial. A strategy this ambitious runs through the same government machinery that just lost eight places on efficiency.',
    paperClaim: 'Anchor Strategy: political-institutional stability is a binding constraint, funded ahead of the clusters.',
  },
];
