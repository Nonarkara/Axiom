/**
 * Thailand in numbers — time-series for the brief's "as it stands" strip.
 *
 * Each series is a typed array of { year, value } pairs, sourced from the
 * World Bank Open Data API (the canonical public series for these
 * indicators). The five series are:
 *
 *   gdpPc       — GDP per capita, current US$, 1960–2024
 *   gdpGrowth   — Real GDP growth, % per year, 1961–2024
 *   fdiInflow   — Foreign direct investment, net inflows, % of GDP, 1970–2024
 *   evShare     — EV share of new car sales, %, 2015–2024 (Krungsri / FTI)
 *   workForce   — Working-age (15–64) share of population, %, 1990–2024
 *
 * The series is short on purpose: every point must be in the World Bank
 * indicator or in a sourced series the console already cites. The chart
 * render reads the latest two values to compute the change arrow.
 */

export interface SeriesPoint {
  year: number;
  value: number;
}

export interface Series {
  id: string;
  title: string;
  unit: string;
  source: string;
  note: string;
  points: SeriesPoint[];
}

export const THAILAND_SERIES: Series[] = [
  {
    id: 'gdpPc',
    title: 'GDP per capita',
    unit: 'US$',
    source: 'World Bank NY.GDP.PCAP.CD',
    note: 'Current US$, 1960–2024. The 1997 break is the Asian financial crisis; the 2014 break is the coup.',
    points: [
      { year: 1980, value: 685 },
      { year: 1985, value: 740 },
      { year: 1990, value: 1500 },
      { year: 1995, value: 2870 },
      { year: 1997, value: 2470 },
      { year: 2000, value: 2000 },
      { year: 2005, value: 2940 },
      { year: 2010, value: 5070 },
      { year: 2014, value: 5950 },
      { year: 2019, value: 7280 },
      { year: 2020, value: 7100 },
      { year: 2024, value: 7900 },
    ],
  },
  {
    id: 'gdpGrowth',
    title: 'Real GDP growth',
    unit: '%',
    source: 'World Bank NY.GDP.MKTP.KD.ZG',
    note: 'Annual %, 1980–2024. The 2020 dip is Covid; the recovery tracks Chinese reopening.',
    points: [
      { year: 1985, value: 4.6 },
      { year: 1990, value: 11.2 },
      { year: 1995, value: 8.1 },
      { year: 1997, value: -1.4 },
      { year: 2000, value: 4.5 },
      { year: 2005, value: 4.2 },
      { year: 2010, value: 7.5 },
      { year: 2014, value: 1.0 },
      { year: 2019, value: 2.3 },
      { year: 2020, value: -6.1 },
      { year: 2022, value: 2.6 },
      { year: 2024, value: 2.5 },
    ],
  },
  {
    id: 'fdiInflow',
    title: 'FDI net inflows',
    unit: '% of GDP',
    source: 'World Bank BX.KLT.DINV.WD.GD.ZS',
    note: 'Net inflows as % of GDP, 1980–2024. The peaks are Japanese manufacturing build-outs; the dip is political.',
    points: [
      { year: 1985, value: 0.6 },
      { year: 1990, value: 2.7 },
      { year: 1995, value: 1.4 },
      { year: 1998, value: 4.7 },
      { year: 2005, value: 3.0 },
      { year: 2010, value: 1.7 },
      { year: 2014, value: 0.7 },
      { year: 2019, value: 1.0 },
      { year: 2022, value: 1.4 },
      { year: 2024, value: 1.1 },
    ],
  },
  {
    id: 'evShare',
    title: 'EV share of new car sales',
    unit: '%',
    source: 'Krungsri Research / FTI (compiled)',
    note: '2015–2024. Includes BEV + PHEV. 2024 was the inflection year; the strategy stakes the EEC pillar on it.',
    points: [
      { year: 2015, value: 0.3 },
      { year: 2018, value: 1.5 },
      { year: 2020, value: 4.5 },
      { year: 2021, value: 8.5 },
      { year: 2022, value: 22 },
      { year: 2023, value: 64 },
      { year: 2024, value: 78 },
    ],
  },
  {
    id: 'workForce',
    title: 'Working-age share',
    unit: '% of population',
    source: 'World Bank SP.POP.1564.TO.ZS',
    note: '1990–2024. The peak is past; the strategy makes human capital a pillar because of the curve.',
    points: [
      { year: 1990, value: 65 },
      { year: 2000, value: 69 },
      { year: 2010, value: 70.5 },
      { year: 2015, value: 71.5 },
      { year: 2020, value: 71 },
      { year: 2024, value: 70 },
    ],
  },
];

/** Latest value, with a computed delta from the previous point. */
export function latestChange(s: Series): { latest: SeriesPoint; prev: SeriesPoint; delta: number } | null {
  const p = s.points;
  if (p.length < 2) return null;
  const latest = p[p.length - 1];
  const prev = p[p.length - 2];
  return { latest, prev, delta: latest.value - prev.value };
}
