/**
 * The eleven economic clusters, scored on four axes.
 * Source: Thailand's Economic Clusters V2 (July 2026), §3–§4 and Table 2.
 *
 * Scores are the author's analytical judgments. Every supporting figure carries
 * the reference it came from.
 */

import type { FactRecord } from './sources.ts';
import type { Adjusted, Scored, ThresholdId } from '../lib/scoring.ts';
import { applyThresholds } from '../lib/scoring.ts';

export interface Cluster extends Scored {
  id: string;
  name: string;
  /** §4 heading gloss — what the stance actually means for this cluster. */
  headline: string;
  facts: Array<FactRecord & { label: string }>;
  /** The paper's stated course of action. */
  action: string;
}

export const CLUSTERS: Cluster[] = [
  {
    id: 'food',
    name: 'Food & agriculture',
    value: 'High',
    growth: 'Low–Med',
    local: 'High',
    sovereignty: 'High',
    stance: 'Keep & upgrade',
    headline:
      "Thailand's clearest sovereignty strength — food security, domestic ownership, broad rural employment — offset by low productivity, an aging workforce and climate exposure.",
    action:
      'Defend and upgrade toward higher-value "future food"; the anchor of the Isan, Northern and Southern provincial economies.',
    facts: [
      { label: 'Share of GDP', value: '8.71%', src: 'tge-agriculture' },
      { label: 'Share of employment', value: '~30%', src: 'docB' },
      {
        label: 'Agri & agro-industrial exports, 2024',
        value: 'US$52.2bn',
        src: 'bp-exports',
        caveat: 'Up 6% year on year. Ministry of Commerce TPSO figures as reported.',
      },
      {
        label: 'Future-food export target, 2027',
        value: '฿500bn',
        src: 'nation-futurefood',
        tier: 'projection',
        caveat: 'A target. Thailand currently ranks 12th globally as a future-food exporter.',
      },
    ],
  },
  {
    id: 'tourism',
    name: 'Tourism & hospitality',
    value: 'High',
    growth: 'Med',
    local: 'High',
    sovereignty: 'Med–High',
    stance: 'Keep & defend',
    headline:
      'Domestically owned and deeply inclusive of SMEs and informal workers — strong local contribution, reasonable sovereignty, but exposed to external demand.',
    action:
      'Defend, diversify source markets, and pivot toward higher-value wellness and medical travel.',
    facts: [
      {
        label: 'Foreign arrivals, 2025',
        value: '32,974,321',
        src: 'bp-tourism',
        caveat: 'Down 7.23% — the first non-pandemic annual decline.',
      },
      { label: 'Foreign tourism revenue, 2025', value: '฿1.54tn', src: 'bp-tourism' },
      {
        label: 'Total tourism revenue incl. domestic',
        value: '฿2.7tn',
        src: 'nation-tourism',
      },
      { label: 'Share of GDP', value: '~12%', src: 'docB' },
      {
        label: 'Chinese arrivals, 2025',
        value: '−34%',
        src: 'bp-tourism',
        caveat: 'Malaysia overtook China as the top source market.',
      },
    ],
  },
  {
    id: 'auto',
    name: 'Automotive (ICE & pickup)',
    value: 'High',
    growth: 'Declining',
    local: 'High',
    sovereignty: 'Med',
    stance: 'Make it exist',
    headline:
      "Southeast Asia's largest producer, with deep value capture and a large parts-SME ecosystem now threatened by the EV transition.",
    action:
      'Managed transition to hybrids and EVs that protects the parts-SME base, supported by hybrid excise incentives for 2026–2032.',
    facts: [
      {
        label: 'Production, 2024',
        value: '1.47m units',
        src: 'bp-autos',
        caveat: 'Down about 20% — a four-year low.',
      },
      {
        label: 'Domestic sales',
        value: '15-year low',
        src: 'bp-autos',
        caveat: 'Amid a roughly 70% loan-rejection rate.',
      },
      { label: 'Local content in pickups', value: 'over 90%', src: 'docB' },
    ],
  },
  {
    id: 'ev',
    name: 'EV & batteries',
    value: 'Med',
    growth: 'High',
    local: 'Low–Med',
    sovereignty: 'Low',
    stance: 'Focus (conditional)',
    headline:
      'The fastest-rising cluster, but value capture is shallow and sovereignty is low.',
    action:
      'Invest, but condition incentives on battery-cell localisation, Thai equity, technology transfer and parts-SME transition funds — otherwise Thailand trades a deep Japanese ICE ecosystem for a shallow Chinese assembly enclave.',
    facts: [
      {
        label: 'BEV registrations, 2025',
        value: '120,301',
        src: 'maverick-ev',
        caveat: 'Up 80.3%; 19.4% penetration.',
      },
      {
        label: 'Chinese brand share of the EV market',
        value: '~70%',
        src: 'usasean-ev',
        caveat:
          'Ranges to ~85% when all EV sales are counted rather than BEV alone; the direction is unambiguous.',
      },
    ],
  },
  {
    id: 'electronics',
    name: 'Electronics / E&E',
    value: 'High',
    growth: 'Med–High',
    local: 'Med',
    sovereignty: 'Low',
    stance: 'Focus / transition',
    headline:
      'The top export category, but a foreign-owned, upstream-import-dependent export platform.',
    action:
      'Focus investment on moving up the value chain — integrated circuits, printed circuit boards, semiconductors — while managing legacy hard-disk-drive production as a cash-generating sunset.',
    facts: [
      { label: 'Share of total exports, 2024', value: '27.4%', src: 'krungsri' },
      {
        label: 'Share of world HDD production',
        value: '~80%',
        src: 'docB',
        caveat: 'Structurally declining, extended by AI and data-centre demand.',
      },
      {
        label: 'Western Digital expansion, BOI-approved',
        value: '฿23.5bn',
        src: 'tbn-wd',
      },
    ],
  },
  {
    id: 'datacenters',
    name: 'Data centres & cloud',
    value: 'Med',
    growth: 'High',
    local: 'Low',
    sovereignty: 'Very Low',
    stance: 'Focus (conditional)',
    headline:
      'Foreign-controlled digital infrastructure: capital-intensive, enclaved, few permanent jobs, high power and water demand, with attendant data-sovereignty risk.',
    action:
      'Welcome capacity but attach conditions — local data-residency guarantees, Thai equity or co-location, renewable-power agreements, and skills transfer.',
    facts: [
      {
        label: 'BOI-approved projects, 2025',
        value: '฿746bn',
        src: 'gdch-dc',
        caveat:
          "The single largest investment magnet of 2025 — anchored by AWS, Google, Microsoft and ByteDance, plus Chinese operators.",
      },
    ],
  },
  {
    id: 'petrochem',
    name: 'Petrochemicals & plastics',
    value: 'High',
    growth: 'Low',
    local: 'Med',
    sovereignty: 'Med',
    stance: 'Keep → specialty',
    headline:
      "ASEAN's largest plastics chain and Thai-owned — a sovereignty positive — but squeezed by Chinese overcapacity and collapsing margins.",
    action:
      'Defend the Thai-owned core (PTTGC, SCGC, Indorama) and accelerate the shift to specialty and bio-based polymers.',
    facts: [
      { label: 'Plastics chain share of GDP, 2023', value: '~6.7%', src: 'docB' },
      { label: 'Margin pressure', value: 'Chinese overcapacity', src: 'krasia' },
    ],
  },
  {
    id: 'steel',
    name: 'Iron & steel',
    value: 'Low–Med',
    growth: 'Declining',
    local: 'Low–Med',
    sovereignty: 'Low',
    stance: 'Make it exist',
    headline:
      'The most distressed cluster — undercut by Chinese import flooding and by Chinese-owned induction-furnace plants inside Thailand.',
    action:
      'Managed restructuring: enforce anti-dumping and standards, apply "Made in Thailand" procurement, and promote green-steel upgrading — without subsidising commodity survival for its own sake.',
    facts: [
      {
        label: 'Capacity utilisation, 2024',
        value: '~28–29%',
        src: 'bp-steel',
        caveat: 'A record low.',
      },
      { label: 'Import dependence', value: '~69%', src: 'bp-steel' },
    ],
  },
  {
    id: 'finance',
    name: 'Finance',
    value: 'High',
    growth: 'Med',
    local: 'Med',
    sovereignty: 'High',
    stance: 'Keep & defend',
    headline:
      'Largely Thai-owned and systemically important — a genuine sovereignty asset, constrained by household debt and rising non-performing loans.',
    action:
      'Defend Thai ownership, manage deleveraging, and modernise cautiously (virtual-bank licensing, PromptPay) without ceding core payment and credit infrastructure.',
    facts: [
      {
        label: 'Household debt, end-2025',
        value: '86.7% of GDP',
        src: 'ceic-debt',
      },
    ],
  },
  {
    id: 'medical',
    name: 'Medical & wellness',
    value: 'Med',
    growth: 'High',
    local: 'Med',
    sovereignty: 'High',
    stance: 'Focus',
    headline:
      'High value, rising growth, good sovereignty, and a natural convergence of tourism, healthcare, aging-society demand and Thai soft power.',
    action:
      'Invest. Thai-owned hospital groups and the most JCI-accredited hospitals in the region make this the cluster where growth and sovereignty already agree.',
    facts: [
      {
        label: 'ASEAN medical & wellness market share, 2024',
        value: '47.7%',
        src: 'gmi-wellness',
        caveat: 'Commercial market research; no official series exists.',
      },
    ],
  },
  {
    id: 'textiles',
    name: 'Textiles & garments',
    value: 'Low',
    growth: 'Declining',
    local: 'Med',
    sovereignty: 'Low',
    stance: 'Make it exist',
    headline:
      'Mature and exposed to low-cost competition, declining in commodity segments.',
    action:
      'Transition toward technical and functional textiles and design-and-branding niches — not defence of commodity mass production.',
    facts: [{ label: 'Commodity segments', value: 'declining', src: 'docB' }],
  },
];

export const CLUSTER_BY_ID = Object.fromEntries(
  CLUSTERS.map((c) => [c.id, c]),
) as Record<string, Cluster>;

/**
 * The only way the UI should read a cluster's current scores.
 *
 * It resolves the published row itself, so an adjusted score can never be fed
 * back in and upgraded twice — the ratchet that would quietly overstate what
 * §6.1 actually claims.
 */
export function adjustedCluster(
  id: string,
  active: ReadonlySet<ThresholdId>,
): Cluster & Adjusted {
  const c = CLUSTER_BY_ID[id];
  const published: Scored = {
    value: c.value,
    growth: c.growth,
    local: c.local,
    sovereignty: c.sovereignty,
    stance: c.stance,
  };
  return { ...c, ...applyThresholds(published, id, active) };
}

/** §5 — the structural finding the whole paper turns on. */
export const PARADOX = {
  title: 'The growth–local–sovereignty paradox',
  points: [
    'The fastest-growing clusters are the least sovereign and least local: data centres, EVs and advanced electronics score high on value and growth but low on both local contribution and sovereignty, and are enclaved in Bangkok and the EEC.',
    'The most sovereign and locally broad clusters — food and agriculture, domestic tourism — grow slowly.',
    'Board of Investment incentives and EV tariff policy are channelling promoted capital into the foreign-controlled, high-growth clusters while the sovereign, broad-based clusters receive comparatively little upgrading investment.',
  ],
  verdict:
    'A GDP-maximising industrial policy therefore actively worsens both spatial inequality and economic sovereignty unless deliberately counterweighted.',
} as const;

/** §6 — what the paper asks area-based industrial policy to do about it. */
export const RECOMMENDATIONS = [
  {
    title: 'Adopt a four-axis cluster scorecard',
    body: 'Use value × growth × local contribution × sovereignty — not GDP alone — as the funding-allocation lens, with explicit thresholds for conditional support of high-growth, low-sovereignty clusters.',
  },
  {
    title: 'Attach conditionality to foreign-controlled "future" clusters',
    body: 'For EVs, tie incentives to battery-cell localisation, Thai joint-venture equity and ICE-parts-SME transition funds; for data centres, require data-residency, renewable power and skills transfer; for electronics, fund the move up-value rather than assembly.',
  },
  {
    title: 'Rebalance toward sovereign, broad-based clusters in lagging regions',
    body: 'Direct area funding to food-processing upgrading, bio-refineries and agri-value-added in Isan, the North and the South, where local contribution and sovereignty are highest and the spatial-inequality payoff is largest.',
  },
  {
    title: 'Manage declining clusters honestly',
    body: 'For ICE parts, legacy HDD, commodity steel and commodity textiles, fund worker and SME transition rather than indefinite survival subsidies, and deploy trade defence for import-flooded steel.',
  },
  {
    title: 'Defend the sovereignty assets',
    body: 'Protect Thai-owned finance and the Thai-owned petrochemical core, steering both toward higher-value niches.',
  },
  {
    title: 'Instrument local-benefit measurement',
    body: 'Commission province-level value-capture and employment-linkage studies using GPP and labour-force micro-data so that "contribution to local" is measured, not assumed.',
  },
] as const;
