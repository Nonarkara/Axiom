/**
 * The Anchor Strategy v1.1 — the strategic layer.
 *
 * Note on probabilities: the report describes its four trajectories in
 * qualitative terms and explicitly calls them "bracket scenarios with explicit
 * probabilities, not forecasts". The Craft edition states the ordering without
 * publishing the numbers, so no numbers are invented here. The likelihood field
 * carries the report's own words.
 */

import type { FactRecord } from './sources.ts';

// ── The central decision ───────────────────────────────────────────────────

export const DECISION = {
  question:
    'Should Thailand side with the United States and its allies, side with China and its alignment partners, or remain unaligned?',
  method:
    'Decision-theoretic payoff analysis across five plausible world-states and four classical decision criteria.',
  options: [
    { name: 'Unaligned — bamboo diplomacy', ev: '+3.85', winner: true },
    { name: 'Lean USA', ev: '−0.45', winner: false },
    { name: 'Lean China', ev: '−0.50', winner: false },
  ],
  result:
    'The unaligned posture dominates by a substantial margin. It wins on three of four criteria and loses only on Maximax — the criterion that judges a strategy purely by its best case — by a single point.',
  condition:
    'The result holds only if the posture is worked: diversification, issue-based alignment, ASEAN amplification, capability that multiple stacks want. Passive hedging is not bamboo diplomacy — it is drift, and drift loses under all four trajectories.',
  src: 'docA',
} as const;

// ── Trajectories ───────────────────────────────────────────────────────────

export type TrajectoryId = 'alpha' | 'beta' | 'gamma' | 'delta';

export interface Trajectory {
  id: TrajectoryId;
  glyph: string;
  name: string;
  summary: string;
  likelihood: FactRecord;
  /** What this trajectory demands of the architecture. */
  implication: string;
}

export const TRAJECTORIES: Trajectory[] = [
  {
    id: 'alpha',
    glyph: 'α',
    name: 'Bloc-ification',
    summary:
      'Renewed great-power consolidation into two stacks. The world goes binary across trade, finance, technology and security.',
    likelihood: {
      value: 'Lower probability, higher impact',
      src: 'docA',
      caveat: 'The report gives an ordering, not a published figure, in this edition.',
    },
    implication:
      'Institutional connector identity fails; Soft Power becomes the load-bearing pillar. An α-contingency must be built before it is tested.',
  },
  {
    id: 'beta',
    glyph: 'β',
    name: 'Archipelago Order',
    summary:
      'Permanent fragmentation — six to eight overlapping sub-orders coexisting without integration, governed by transactional rather than rule-based logic.',
    likelihood: {
      value: 'Most probable through 2035',
      src: 'docA',
      caveat: 'The strategy is a probability-weighted bet on this trajectory.',
    },
    implication:
      'The trajectory the architecture is designed for. Connector infrastructure and ASEAN diplomacy both perform at their best here.',
  },
  {
    id: 'gamma',
    glyph: 'γ',
    name: 'Reformed Concert',
    summary:
      'A reformed concert of major powers — achievable, the report argues, only through near-catastrophe.',
    likelihood: {
      value: 'Still lower probability',
      src: 'docA',
    },
    implication:
      'The dividend trajectory for Soft Power and ASEAN-anchored diplomacy. Nothing needs to be built specifically for it.',
  },
  {
    id: 'delta',
    glyph: 'δ',
    name: 'Cascade Breakdown',
    summary:
      "The system fails: coupled stresses exceed the international order's absorptive capacity.",
    likelihood: {
      value: 'Low probability, consequence-rich',
      src: 'docA',
      caveat: 'Added in v1.0 because the first three trajectories all assumed the system reorganises rather than fails.',
    },
    implication:
      'The operating environment the Sovereign Foundation is principally designed for. Every outward-facing pillar collapses; the Foundation is what remains.',
  },
];

export const TRAJECTORY_BY_ID = Object.fromEntries(
  TRAJECTORIES.map((t) => [t.id, t]),
) as Record<TrajectoryId, Trajectory>;

// ── The architecture ───────────────────────────────────────────────────────

export interface Pillar {
  n: number;
  name: string;
  fn: string;
}

export const PILLARS: Pillar[] = [
  {
    n: 1,
    name: 'Connector Infrastructure',
    fn: 'Geographic and institutional bridge between sub-orders',
  },
  {
    n: 2,
    name: 'Specialized Industrial Niches',
    fn: 'Economic depth that survives any trajectory',
  },
  {
    n: 3,
    name: 'ASEAN-Anchored Diplomacy',
    fn: 'Force-multiplier for middle-power weight',
  },
  {
    n: 4,
    name: 'Soft Power Monetization',
    fn: 'Strategic brand premium and cognitive-domain presence — standing in what the world watches, reads and believes',
  },
  {
    n: 5,
    name: 'Human Capital and Demographic Renewal',
    fn: 'Talent and demographic substance of the strategy',
  },
];

export const FOUNDATION = {
  name: 'Sovereign Foundation',
  thesis:
    'The five pillars describe what Thailand offers the world. The Foundation describes what Thailand depends on no one for. It is not a sixth pillar — it is the ground beneath them.',
  doctrine:
    'Anchored in Sufficiency Economy Philosophy, whose third principle — self-immunity (kān mī phūmkhumkān) — names the missing architectural layer directly.',
  components: [
    'Food sovereignty',
    'Water sovereignty',
    'Energy sovereignty',
    'Climate adaptation',
    'Social cohesion',
  ],
} as const;

export const DOCTRINES = [
  {
    name: 'Technology Sovereignty Doctrine',
    rule: 'The 35% rule',
    ruleBody:
      'Dependence on any single technology stack is capped at thirty-five percent.',
    domains: [
      'AI and compute',
      'The semiconductor floor',
      'Digital identity and payments',
      'Networking and data standards',
      'Space access',
      'Critical software autonomy',
      'Cybersecurity',
    ],
  },
  {
    name: 'Selective Neutrality and Defense Doctrine',
    rule: 'The 25% rule',
    ruleBody:
      'Dependence on any single defense supplier is capped at twenty-five percent. Major Non-NATO Ally status is operationally re-converted — kept, but re-purposed in practice — not divested.',
    domains: [
      'Armed neutrality with multi-stack interoperability',
      'Asymmetric, denial-focused force structure — not power projection',
      'Pre-positioned playbook: Taiwan',
      'Pre-positioned playbook: Myanmar',
      'Pre-positioned playbook: South China Sea',
    ],
  },
] as const;

// ── The stress test ────────────────────────────────────────────────────────

export interface StressRow {
  layer: string;
  scores: Record<TrajectoryId, number>;
  mean: number;
  /** The finding the report draws from this row. */
  finding: string;
}

export const STRESS_GRID: StressRow[] = [
  {
    layer: 'Connector Infrastructure',
    scores: { alpha: 5, beta: 9, gamma: 6, delta: 2 },
    mean: 5.5,
    finding:
      'Trajectory-sensitive. Physical connector infrastructure retains commercial value across all trajectories; institutional connector identity fails under bloc-ification and cascade.',
  },
  {
    layer: 'Specialized Industrial Niches',
    scores: { alpha: 6, beta: 8, gamma: 8, delta: 3 },
    mean: 6.3,
    finding: 'A robust workhorse — a prerequisite pillar, not a distinctive one.',
  },
  {
    layer: 'ASEAN-Anchored Diplomacy',
    scores: { alpha: 3, beta: 7, gamma: 6, delta: 3 },
    mean: 4.8,
    finding:
      'The single largest pillar-level structural risk. Build the ASEAN-5 minilateral — Thailand, Indonesia, Malaysia, Vietnam, Singapore — as redundancy, before ASEAN-10 fragments.',
  },
  {
    layer: 'Soft Power Monetization',
    scores: { alpha: 8, beta: 9, gamma: 9, delta: 5 },
    mean: 7.8,
    finding:
      'Load-bearing in the worst external trajectory and dividend-generating in the best. It should be funded first.',
  },
  {
    layer: 'Human Capital and Demographic Renewal',
    scores: { alpha: 5, beta: 8, gamma: 8, delta: 4 },
    mean: 6.3,
    finding:
      'A robust workhorse. No talent, no anchor — Pillar 5 is what makes Pillars 1 through 4 viable.',
  },
  {
    layer: 'Sovereign Foundation',
    scores: { alpha: 8, beta: 8, gamma: 8, delta: 10 },
    mean: 8.5,
    finding:
      "The most resilient layer overall and the only layer designed for cascade. It is the strategy's δ-insurance and the precondition for recovery.",
  },
];

// ── Money ──────────────────────────────────────────────────────────────────

export interface EnvelopeRow {
  layer: string;
  capital: FactRecord;
  ofGdp: FactRecord;
  total?: boolean;
}

export const ENVELOPE = {
  horizon: '10 years',
  rows: [
    {
      layer: 'Five Pillars',
      capital: { value: '$38B', src: 'docA' },
      ofGdp: { value: '≈1.25%', src: 'docA' },
    },
    {
      layer: 'Sovereign Foundation',
      capital: { value: '$18B', src: 'docA' },
      ofGdp: { value: '≈0.60%', src: 'docA' },
    },
    {
      layer: 'Technology Sovereignty Doctrine',
      capital: { value: '$4B', src: 'docA', caveat: 'Net new spending.' },
      ofGdp: { value: '≈0.13%', src: 'docA' },
    },
    {
      layer: 'Defense Doctrine',
      capital: { value: '$3–4B', src: 'docA', caveat: 'Net new spending.' },
      ofGdp: { value: '≈0.10%', src: 'docA' },
    },
    {
      layer: 'Total programme',
      capital: { value: '≈$63–64B', src: 'docA' },
      ofGdp: { value: '≈2.1%', src: 'docA', caveat: 'Of GDP per year, over ten years.' },
      total: true,
    },
  ] as EnvelopeRow[],
} as const;

// ── Sequence ───────────────────────────────────────────────────────────────

export const PHASES = [
  {
    phase: 'Phase 1',
    years: 'Years 1–3',
    name: 'Foundation',
    body: 'Doctrine publication, ASEAN-5 launch, Sovereign Foundation priorities.',
  },
  {
    phase: 'Phase 2',
    years: 'Years 3–6',
    name: 'Capability build',
    body: 'Industrial facilities ramping, value chains formalising, Foundation at scale.',
  },
  {
    phase: 'Phase 3',
    years: 'Years 6–10',
    name: 'Anchor realisation',
    body: 'Three to four niches of global indispensability, Foundation operational, doctrines tested.',
  },
] as const;

export const CLOCK =
  'Thailand has approximately ten years before the strategic option set narrows substantially.';

// ── The pattern-set ────────────────────────────────────────────────────────

export interface Comparator {
  name: string;
  scale: string;
  pattern: string;
  lesson: string;
  takes: string[];
  doesNotTransfer: string[];
}

export const COMPARATORS: Comparator[] = [
  {
    name: 'Singapore',
    scale: 'City-state · 5.6M',
    pattern: 'Concentrated capability, multi-stack fluency, governance premium',
    lesson: 'Institutional quality is the multiplier — build to global standard from inception.',
    takes: [
      'The sovereign industrial investment fund pattern — Temasek governance, not typical state-enterprise structure.',
      'Water and food sovereignty run as strategic portfolios.',
      'Multi-alignment as operational capability; the 35% and 25% rules are the Thai analogue.',
    ],
    doesNotTransfer: [
      'Scale — 5.6M against 70M+ changes the governance mechanics.',
      'Single-party continuity; Thailand must build programmatic continuity through legislation instead.',
      'Geographic uniqueness — Singapore inherited its indispensability; Thailand has to build it.',
    ],
  },
  {
    name: 'Vietnam',
    scale: 'Middle-scale · 100M',
    pattern: 'Active hedging, demographic acceleration, industrial substitution',
    lesson: 'Multi-alignment is a capability, not a posture — executed through doctrine and framework portfolio.',
    takes: [
      'The trade-agreement portfolio as a coercion-cost multiplier.',
      'Doctrine published before it is tested — the Four No’s constrain governments in advance.',
      'FDI-plus-conditionality as the default mechanism for capital-intensive sub-sectors.',
    ],
    doesNotTransfer: [
      'Demography — Vietnam is where Thailand was in the 1990s.',
      'Single-party continuity.',
      'The low-income take-off baseline; Thailand is already past that stage.',
    ],
  },
  {
    name: 'Switzerland',
    scale: 'Small state · 8.8M',
    pattern: 'Armed neutrality, specialized indispensability, banking sovereignty',
    lesson: 'Restraint compounds — each refusal builds reputational capital over time.',
    takes: [
      'The armed part of armed neutrality — asymmetric, denial-focused force structure.',
      'Restraint commitments as reputation-building.',
      'Bangkok as the regional Geneva: plurilateral hosting, Buddhist-Islamic convening.',
    ],
    doesNotTransfer: [
      'Alpine defensibility.',
      'Mass conscription as a continuity mechanism.',
      'Two centuries of institutional depth; Thailand compensates with explicit doctrinal publication.',
    ],
  },
  {
    name: 'India',
    scale: 'Large state · 1.4B',
    pattern: 'Strategic autonomy, civilizational scale, tech-stack sovereignty',
    lesson: 'Doctrine before capability — name the commitment first, then invest to it.',
    takes: [
      'Public commitment shapes the investment sequence.',
      'Multi-vector procurement validated at scale — the 25% rule codifies the Indian pattern.',
      'Coalition portfolio discipline so no coalition constrains the others.',
    ],
    doesNotTransfer: [
      'Civilizational scale and the procurement leverage that comes with it.',
      'Subcontinental geographic separation.',
      'Nuclear deterrence — Thailand’s coercion-resistance must come from Foundation depth instead.',
    ],
  },
];

export const SHARED_PATTERN = [
  'Specialized indispensability in a small number of niches',
  'Disciplined multi-alignment where great-power pressure is highest',
  'Sovereign foundations at home that make coercion expensive',
  'Doctrinal restraint on power projection',
  'Continuity of doctrine across political transitions',
];

export const WHAT_IS_NEW = [
  'The cascade trajectory and failure-mode analysis applied to a middle-power anchor strategy.',
  'The nine-cluster geographic architecture at national resolution.',
  'Sufficiency Economy Philosophy as doctrinal grounding for the Sovereign Foundation.',
];

// ── Industrial bets ────────────────────────────────────────────────────────

export const BETS = {
  thesis:
    'The highest-robustness bets are not in the most-discussed industries but in their adjacent value-chain positions.',
  adjacent: [
    'Battery recycling',
    'Critical mineral recycling',
    'Compound semiconductors',
    'IC substrates',
    'Advanced packaging',
    'EV powertrain integration',
    'Rare earth processing',
  ],
  niches: [
    'Cultural content',
    'Medical, wellness and longevity',
    'Food innovation',
    'Halal industries',
    'Buddhist soft power',
  ],
  model:
    'The Korean model — semiconductors plus content plus food plus cosmetics plus medical — is the relevant pattern, not the Taiwanese model of single-industry concentration.',
} as const;

export const THESIS = 'The choice is not which side. The choice is what kind of indispensability to build.';
