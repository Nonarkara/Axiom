/**
 * The literature register — §10.
 *
 * Thirteen studies from the fields the argument sits inside: hedging theory,
 * international-order research, soft power, sufficiency-economy scholarship,
 * late-industrialization, Thai political economy, ASEAN regionalism and
 * Thai demography. None is cited by either paper; all are tiered `external`
 * in the source register so they can never be mistaken for the author's own
 * evidence base.
 *
 * Every citation below was verified against the Crossref registry and its DOI
 * confirmed to resolve before shipping (the Craft-slug lesson: never commit a
 * URL found by memory).
 *
 * Each study is also tagged with `geography` — the regions it speaks to on
 * the §07 map. The cross-analysis at the foot of §10 turns this field into a
 * "what the literature says about the country" reading, region by region.
 *
 * The verdicts, the glyph matrix and the geography tags are this console's
 * judgment — they carry no numbers, so the conservation law is untouched, but
 * the section states their status plainly in copy.
 */

import type { RegionId } from '../lib/thailandProvinces.ts';

export type Verdict = 'supports' | 'extends' | 'complicates';

export type ComponentId = 'decision' | 'trajectories' | 'pillars' | 'foundation' | 'doctrines';

/** The five parts of the argument the literature is read against. */
export const ARGUMENT_COMPONENTS: Array<{ id: ComponentId; label: string; note: string }> = [
  {
    id: 'decision',
    label: 'The decision',
    note: 'Unaligned posture beats leaning either way — §01.',
  },
  {
    id: 'trajectories',
    label: 'The trajectories',
    note: 'α β γ δ brackets on the transition — §02.',
  },
  {
    id: 'pillars',
    label: 'The five pillars',
    note: 'Connector, niches, ASEAN, soft power, human capital — §03.',
  },
  {
    id: 'foundation',
    label: 'The Sovereign Foundation',
    note: 'Food, water, energy, climate, social cohesion — §03.',
  },
  {
    id: 'doctrines',
    label: 'The two doctrines',
    note: 'The 35% and 25% dependence caps — §03.',
  },
];

export interface Study {
  id: string;
  /** Key into SOURCES. */
  src: string;
  authors: string;
  year: string;
  title: string;
  venue: string;
  /** One line: what the study actually found. */
  finding: string;
  /** 2–3 sentences: how it bears on the argument, divergence included. */
  analysis: string;
  verdict: Verdict;
  /** Glyph matrix: which components the study speaks to, and how directly. */
  speaks: Partial<Record<ComponentId, 'direct' | 'partial'>>;
  /** Which regions on the §07 map this study is most relevant to. */
  geography?: RegionId[];
}

export const LITERATURE: Study[] = [
  {
    id: 'kuik-2008',
    src: 'kuik-2008',
    authors: 'Kuik, Cheng-Chwee',
    year: '2008',
    title: 'The Essence of Hedging: Malaysia and Singapore’s Response to a Rising China',
    venue: 'Contemporary Southeast Asia 30(2), 203–227',
    finding:
      'Small-state hedging is not indecision but a deliberate posture — engaging the rising power on economics while counter-weighting it in security — chosen when power shifts are underway and outcomes cannot be forecast.',
    analysis:
      'This is the academic statement of the paper’s central claim that passive hedging is drift and worked hedging is strategy. Kuik’s Malaysia and Singapore institutionalise the same dual track the Anchor Strategy calls bamboo diplomacy, and his definition — insurance across opposite contingencies — is exactly what §01 means by a posture that must be worked. Where Kuik stops is scope: his hedge is a security positioning; the strategy extends the same logic into industrial and technological architecture.',
    verdict: 'supports',
    speaks: { decision: 'direct', trajectories: 'partial', doctrines: 'partial' },
    geography: ['bkk', 'east', 'central'],
  },
  {
    id: 'ciorciari-2010',
    src: 'ciorciari-2010',
    authors: 'Ciorciari, John D.',
    year: '2010',
    title: 'The Limits of Alignment: Southeast Asia and the Great Powers since 1975',
    venue: 'Georgetown University Press',
    finding:
      'Across four decades of Southeast Asian cases, alignment with a great power raised exposure to compellence; alignment-diversity — letting no patron dominate — was the measurable lever of small-state autonomy.',
    analysis:
      'The 35% and 25% rules are Ciorciari’s conclusion expressed as procurement arithmetic: cap any single patron’s share and coercion becomes expensive. Thailand is one of his own cases, which makes this the closest thing the doctrine has to a tested precedent. His caveat is the strategy’s too — autonomy gains are real but finite, and best preserved while great-power competition stays below a threshold the strategy cannot control.',
    verdict: 'supports',
    speaks: { decision: 'direct', trajectories: 'partial', foundation: 'partial', doctrines: 'direct' },
    geography: ['bkk', 'east', 'northeast'],
  },
  {
    id: 'farrell-newman-2019',
    src: 'farrell-newman-2019',
    authors: 'Farrell, Henry & Newman, Abraham L.',
    year: '2019',
    title: 'Weaponized Interdependence: How Global Economic Networks Shape State Coercion',
    venue: 'International Security 44(1), 42–79',
    finding:
      'Global economic and information networks concentrate into hubs and chokepoints; states that control them can weaponise finance, information and supply flows against dependent states.',
    analysis:
      'This is the mechanism underneath trajectory α and the entire Technology Sovereignty Doctrine: dependence on a single stack is exposure to someone else’s chokepoint, and the panopticon effect means the hub sees the node. The connector-pillar ambition is recognisably an attempt to become a minor hub rather than a node. Farrell and Newman’s own caution cuts the other way — hub power accrues to very few states, and middle powers mostly live on the chokepoint side of the network, which is why the doctrine caps dependence rather than chasing dominance.',
    verdict: 'supports',
    speaks: { decision: 'partial', trajectories: 'direct', pillars: 'partial', doctrines: 'direct' },
    geography: ['bkk', 'east', 'central'],
  },
  {
    id: 'goh-2013',
    src: 'goh-2013',
    authors: 'Goh, Evelyn',
    year: '2013',
    title: 'The Struggle for Order: Hegemony, Hierarchy, and Transition in the Contemporary International System',
    venue: 'Oxford University Press',
    finding:
      'Order transition in Asia is best read as negotiated hierarchy: weaker states accommodate the strongest power asymmetrically while enmeshing it in institutions — not as a multipolar balance in which states choose sides.',
    analysis:
      'This is the strongest counter-reading in the register. Goh’s evidence is that Southeast Asian states do not face a side-choosing decision at all; they bargain position within whatever hierarchy holds, as they did under American primacy and are doing under Chinese weight. The unaligned posture survives that reading — accommodation is not alignment — but the strategy’s sovereigntist ambition goes further than Goh’s cases show small states achieving, and her framework would call the four symmetric trajectories a colder abstraction than the negotiated, lopsided order the region actually runs.',
    verdict: 'complicates',
    speaks: { decision: 'partial', trajectories: 'direct', pillars: 'partial' },
    geography: ['bkk', 'north', 'south'],
  },
  {
    id: 'nye-1990',
    src: 'nye-1990',
    authors: 'Nye, Joseph S.',
    year: '1990',
    title: 'Soft Power',
    venue: 'Foreign Policy (80), 153–171',
    finding:
      'Co-optation — making others want what you want — is a distinct resource of statecraft, resting on culture, political values and legitimacy rather than on coercion or payment.',
    analysis:
      'Pillar 4 stands on this concept, and Nye’s 1990 context (a United States worried about relative decline) rhymes with the strategy’s question of what survives when material leverage narrows. The strategy’s move beyond Nye is monetization: he frames soft power as attraction in service of policy; the paper charges for the brand while it attracts. Nye’s own caveat is the one the pillar must carry — commercialised culture can dilute the authenticity that made it attractive in the first place.',
    verdict: 'extends',
    speaks: { decision: 'partial', pillars: 'direct' },
    geography: ['bkk', 'north', 'south'],
  },
  {
    id: 'undp-2007',
    src: 'undp-2007',
    authors: 'UNDP',
    year: '2007',
    title: 'Thailand Human Development Report 2007: Sufficiency Economy and Human Development',
    venue: 'United Nations Development Programme',
    finding:
      'Applied sufficiency economy at national scale: moderation, reasonableness and self-immunity as conditions for sustainable human development — with the 1997 crisis as the bill for their absence.',
    analysis:
      'The Sovereign Foundation’s doctrinal grounding is not invented. Self-immunity is the third SEP condition, and this country report is its most authoritative statement — the strategy cites the philosophy; the report is where the philosophy was already doing this work. Read against §03, the Foundation is SEP translated into five named assets, and the 1997 crisis plays the role δ plays in the stress grid: the case in which only the immune layer matters.',
    verdict: 'supports',
    speaks: { pillars: 'partial', foundation: 'direct' },
    geography: ['northeast', 'north', 'central'],
  },
  {
    id: 'mongsawad-2010',
    src: 'mongsawad-2010',
    authors: 'Mongsawad, Prasopchoke',
    year: '2010',
    title: 'The Philosophy of the Sufficiency Economy: A Contribution to the Theory of Development',
    venue: 'Asia-Pacific Development Journal 17(1)',
    finding:
      'Formalises SEP as development theory — three conditions plus two implementing instruments, knowledge and virtue — and argues it complements rather than replaces growth-oriented economics.',
    analysis:
      'Where the UNDP report is the policy statement, this is the theory: it gives the Foundation an academic lineage the papers invoke only implicitly. It also answers the obvious objection — that sufficiency means stagnation — by design, since the framework is explicitly a complement to growth policy, not a substitute for it. The strategy’s contribution runs the other direction: making self-immunity operational at industrial resolution, with the 35% rule as self-immunity with a number attached.',
    verdict: 'extends',
    speaks: { pillars: 'partial', foundation: 'direct', doctrines: 'partial' },
    geography: ['northeast', 'central', 'bkk'],
  },
  {
    id: 'knodel-2009',
    src: 'knodel-2009',
    authors: 'Knodel, John',
    year: '2009',
    title: 'Older Persons in Thailand: A Demographic, Social and Economic Profile',
    venue: 'Ageing International 34(1–3), 11–35',
    finding:
      'Thailand’s ageing is rapid, early and permanent — fertility fell below replacement decades ago — and older persons rely overwhelmingly on family support just as co-residence is declining.',
    analysis:
      'Pillar 5’s demographic premise, with the evidence attached: the workforce contraction is scheduled, not speculative, which is why the strategy makes human capital a pillar rather than an afterthought. The complication the strategy must carry alongside it: the same ageing that justifies demographic renewal strains the fiscal envelope in §04 that funds every other layer, and the family-based support system Knodel documents is the social-cohesion asset the Foundation lists but does not cost.',
    verdict: 'supports',
    speaks: { pillars: 'direct', foundation: 'partial' },
    geography: ['northeast', 'central', 'north'],
  },
  {
    id: 'amsden-2001',
    src: 'amsden-2001',
    authors: 'Amsden, Alice H.',
    year: '2001',
    title: 'The Rise of "The Rest": Challenges to the West from Late-Industrializing Economies',
    venue: 'Oxford University Press',
    finding:
      'Late-industrializing economies develop by combining foreign technology with local learning behind protective and disciplining institutions — the "Rest" includes not just the four East Asian tigers but any country with the policy discipline to climb the value chain.',
    analysis:
      'This is the doctrine underneath the Specialized Industrial Niches pillar. Amsden\'s argument is that late-industrialization is not imitation; it is technology transfer with domestic ownership of the learning. The Eastern Seaboard — the EEC\'s predecessor — was Thailand\'s first exercise in this discipline, and the 35% cap on technology stack dependence is a successor rule: same logic, lower tolerance. Where the strategy extends Amsden is in naming geography and digital stacks as the specific assets worth disciplining; her framework is industry-wide, while the strategy is stack-specific.',
    verdict: 'supports',
    speaks: { pillars: 'direct', doctrines: 'direct' },
    geography: ['east', 'central', 'bkk'],
  },
  {
    id: 'pempel-2010',
    src: 'pempel-2010',
    authors: 'Pempel, T. J.',
    year: '2010',
    title: 'Soft Balancing, Hedging, and Institutional Darwinism: The Economic-Security Link in East Asia',
    venue: 'Asian Survey 50(6), 1080–1103',
    finding:
      'East Asian responses to a rising China are neither pure balancing nor pure bandwagoning: states use a portfolio of low-cost, reversible moves — institutional hedging, economic security, partial alignment — and keep their options open as the system reorganises.',
    analysis:
      'Pempel refines Kuik by treating hedging as a portfolio of reversible bets rather than a single posture, which is exactly the texture the §01 decision matrix reads off. The economic-security linkage he names is also why the cluster paper is necessary: alignment choices only buy sovereignty if the underlying economic platform is also plural. His caveat is the strategy\'s caveat: hedging only works until the cost of staying uncommitted exceeds the cost of choosing; the ten-year clock in the brief is the strategy\'s estimate of when the deadline bites.',
    verdict: 'extends',
    speaks: { decision: 'direct', trajectories: 'direct' },
    geography: ['bkk', 'north', 'east'],
  },
  {
    id: 'doner-2009',
    src: 'doner-2009',
    authors: 'Doner, Richard F., Ritchie, Bryan K. & Slater, Dan',
    year: '2009',
    title: 'The Politics of Uneven Development: Thailand\'s Economic Growth in Comparative Perspective',
    venue: 'Cambridge University Press',
    finding:
      'Thailand\'s growth is best explained by coalitions of state, capital and labour that selectively upgrade — modern sectors climb, traditional sectors stay — producing durable spatial and sectoral concentration rather than convergence.',
    analysis:
      'This is the political-economy reading of the 16.5× GPP gap. The 48% in Bangkok and the EEC is not an accident of agglomeration; it is the system working as designed under the coalitions the book names. Where Doner\'s argument complicates the strategy: the same coalitions that built the platform are the ones that resist the distributive rebalancing the strategy calls for, which is why the Foundation is named "sovereign" rather than "developmental" — it works around the coalitions that own the platform.',
    verdict: 'supports',
    speaks: { pillars: 'direct', foundation: 'partial' },
    geography: ['bkk', 'east', 'northeast'],
  },
  {
    id: 'acharya-2014',
    src: 'acharya-2014',
    authors: 'Acharya, Amitav',
    year: '2014',
    title: 'Constructing a Security Community in Southeast Asia (3rd ed.)',
    venue: 'Routledge',
    finding:
      'ASEAN has produced a "comfortable" regional order through habit-formation and inclusivist norms — power is mediated, not balanced — and small states are best served by working within, not against, the regional order.',
    analysis:
      'Acharya reads ASEAN as a security community in the making; the Anchor Strategy\'s ASEAN-Anchored Diplomacy pillar is the same reading applied to Thailand specifically. His framework supports the strategy\'s claim that the middle path is more than absence of choice — it is participation in a regional order that compounds rather than cancels. The strategy extends Acharya by naming the period when this compounds (the 10-year clock) and the threat that breaks it (a major-power war that the architecture is stress-tested against in §02).',
    verdict: 'extends',
    speaks: { decision: 'partial', pillars: 'direct', trajectories: 'partial' },
    geography: ['bkk', 'north'],
  },
  {
    id: 'pasuk-baker-2009',
    src: 'pasuk-baker-2009',
    authors: 'Phongpaichit, Pasuk & Baker, Chris',
    year: '2009',
    title: 'A History of Thailand (2nd ed.)',
    venue: 'Cambridge University Press',
    finding:
      'Thailand\'s modern history is a recurring pattern: a state-led economic push creates a Bangkok-centred platform, which then generates the political contradictions that bring it down — and the cycle repeats because the underlying state structure does not change.',
    analysis:
      'This is the longer-cycle context for the §01 decision: the Bangkok-Isaan economic gap the brief documents is not a new fact, it is the most recent repetition of a pattern that goes back to the 19th century. The strategy\'s contribution is the explicit recognition that the pattern is now an international exposure (under α or δ) rather than a domestic one — which is the move that turns sufficiency economy from a moral framework into a Sovereign Foundation. Pasuk and Baker\'s work stops at national history; the strategy imports that history into the multipolar frame the literature check now requires.',
    verdict: 'supports',
    speaks: { pillars: 'partial', foundation: 'partial', decision: 'partial' },
    geography: ['bkk', 'northeast', 'central'],
  },
];