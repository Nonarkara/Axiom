/**
 * Where the analysis lands on the ground.
 *
 * Two different geographies are held here and must not be confused:
 *
 *   REGIONS            — the seven NESDC regions and their GDP/population
 *                        shares, from Economic Clusters V2, Table 1. Sourced.
 *
 *   STRATEGIC_CLUSTERS — the nine strategic clusters named in the Anchor
 *                        Strategy. The names and identities are the paper's.
 *                        The PROVINCE MEMBERSHIP IS NOT: the report names the
 *                        nine clusters without enumerating their provinces, so
 *                        the mapping below is authored here to make the map
 *                        drawable, and is tiered `derived` everywhere it
 *                        surfaces. The provenance test enforces that.
 */

import type { FactRecord } from './sources.ts';
import type { TrajectoryId } from './anchor.ts';
import { REGION_OF, PROVINCE_BY_CODE } from '../lib/thailandProvinces.ts';
import type { RegionId } from '../lib/thailandProvinces.ts';

export interface Region {
  id: RegionId;
  name: string;
  gdpShare: FactRecord;
  popShare: FactRecord;
  dominant: string;
}

/** Economic Clusters V2, Table 1 — anchored to the NESDC GPP series. */
export const REGIONS: Region[] = [
  {
    id: 'bkk',
    name: 'Bangkok (BMR)',
    gdpShare: { value: '~47–48%', src: 'nesdc-gpp' },
    popShare: { value: '~24%', src: 'nesdc-gpp' },
    dominant: 'Finance, services, trade, corporate HQ; HDD and E&E nearby',
  },
  {
    id: 'east',
    name: 'Eastern (EEC)',
    gdpShare: { value: '~18%', src: 'nesdc-gpp' },
    popShare: { value: '~9%', src: 'nesdc-gpp' },
    dominant: 'Autos, petrochemicals, electronics, data centres',
  },
  {
    id: 'northeast',
    name: 'Northeastern (Isan)',
    gdpShare: { value: '~9–11.5%', src: 'nesdc-gpp' },
    popShare: {
      value: '~27–34%',
      src: 'nesdc-gpp',
      caveat:
        'Population denominators differ by source: the NESDC series gives ~27%, registered population ~34%.',
    },
    dominant: 'Rice, cassava, sugar, rubber',
  },
  {
    id: 'north',
    name: 'Northern',
    gdpShare: { value: '~7.7%', src: 'nesdc-gpp' },
    popShare: { value: '~16.5%', src: 'nesdc-gpp' },
    dominant: 'Agriculture, Chiang Mai tourism, handicrafts',
  },
  {
    id: 'south',
    name: 'Southern',
    gdpShare: { value: '~8.4%', src: 'nesdc-gpp' },
    popShare: { value: '~13.8%', src: 'nesdc-gpp' },
    dominant: 'Rubber, palm oil, fisheries, Andaman tourism',
  },
  {
    id: 'central',
    name: 'Central (excl. BMR)',
    gdpShare: { value: '~6.1%', src: 'nesdc-gpp' },
    popShare: { value: '~4.6%', src: 'nesdc-gpp' },
    dominant: 'Agro-processing, Ayutthaya manufacturing',
  },
  {
    id: 'west',
    name: 'Western',
    gdpShare: { value: '~3.5%', src: 'nesdc-gpp' },
    popShare: { value: '~5.3%', src: 'nesdc-gpp' },
    dominant: 'Agriculture, sugar',
  },
];

export const REGION_BY_ID = Object.fromEntries(
  REGIONS.map((r) => [r.id, r]),
) as Record<RegionId, Region>;

/**
 * Midpoint of a published share string ("~47–48%" → 47.5). Used so the map
 * and the paired bars cannot drift from the table they sit next to. Only for
 * percentage shares — never for baht figures, whose commas are thousands.
 */
export function parseShareMid(value: string): number {
  const nums = value.match(/[\d.]+/g);
  if (!nums?.length) return 0;
  return nums.map(Number).reduce((a, b) => a + b, 0) / nums.length;
}

/**
 * Region GDP share as a 0…1 intensity for the choropleth. Parsed from the
 * midpoint of each published range so the map cannot drift from the table.
 * Bangkok's ~48% is the ceiling.
 */
export function regionIntensity(id: RegionId): number {
  return Math.min(1, parseShareMid(REGION_BY_ID[id].gdpShare.value) / 48);
}

/** §2.2 — the spatial concentration finding, at its sharpest. */
export const GPP_GAP: Array<FactRecord & { label: string }> = [
  {
    label: 'Rayong — highest GPP per capita, 2024',
    value: '฿1,003,497',
    src: 'nesdc-gpp',
  },
  {
    label: 'Narathiwat — lowest GPP per capita, 2024',
    value: '฿60,876',
    src: 'nesdc-gpp',
  },
  {
    label: 'The gap',
    value: '16.5×',
    src: 'nesdc-gpp',
    caveat: 'Up from 14.5× in 2021 — the gap is widening, not closing.',
  },
];

// ── The nine strategic clusters (Anchor Strategy) ──────────────────────────

export interface StrategicCluster {
  id: string;
  name: string;
  /** What the cluster is for, in the report's terms. */
  role: string;
  provinces: string[];
  /** Carries the `derived` tier that marks this mapping as the console's own. */
  membership: FactRecord;
}

const derivedMembership = (n: number): FactRecord => ({
  value: `${n} provinces`,
  src: 'docA',
  tier: 'derived',
  caveat:
    'The Anchor Strategy names the nine clusters but does not enumerate their provinces. This membership is the console’s reading, offered so the geography can be drawn — not the report’s.',
});

const P = (...codes: string[]) => codes;

export const STRATEGIC_CLUSTERS: StrategicCluster[] = [
  {
    id: 'eec',
    name: 'EEC Core',
    role: 'Autos, petrochemicals, electronics and the data-centre build-out — the highest-value and least sovereign geography at once.',
    provinces: P('CBI', 'RYG', 'CCO'),
    membership: derivedMembership(3),
  },
  {
    id: 'bmr',
    name: 'Bangkok Metropolitan',
    role: 'Finance, corporate command, services trade — the sovereignty asset and the concentration problem in one place.',
    provinces: P('BKK', 'NBI', 'PTE', 'SPK', 'SKN', 'NPT'),
    membership: derivedMembership(6),
  },
  {
    id: 'north-wellness',
    name: 'Northern Wellness & Creative Belt',
    role: 'Medical-wellness-longevity and cultural content — two of the five niche categories that outscore the headline industrial sectors.',
    provinces: P('CMI', 'CRI', 'LPN', 'LPG', 'MSN', 'PYO', 'NAN', 'PRE'),
    membership: derivedMembership(8),
  },
  {
    id: 'south-coastal',
    name: 'Southern Coastal',
    role: 'Andaman and Gulf tourism, rubber, palm oil and fisheries — high local contribution, exposed to external demand.',
    provinces: P('PKT', 'KBI', 'PNA', 'SNI', 'RNG', 'TRG', 'CPN', 'NRT', 'SKA', 'PLG'),
    membership: derivedMembership(10),
  },
  {
    id: 'deep-south',
    name: 'Deep South Halal-Islamic Bridge',
    role: 'Halal industry and the Islamic-world connection — and the lowest GPP per capita in the country.',
    provinces: P('YLA', 'PTN', 'NWT', 'STN'),
    membership: derivedMembership(4),
  },
  {
    id: 'isaan',
    name: 'Isaan Agri-Industrial & Mekong Gateway',
    role: 'Food sovereignty and the Mekong land bridge — a quarter to a third of the population on about a tenth of GDP.',
    provinces: P(
      'NMA', 'UBN', 'KKN', 'UDN', 'BRM', 'SRN', 'SSK', 'RET', 'CPM', 'KSN',
      'MKM', 'SNK', 'NKI', 'LEI', 'YST', 'NPM', 'NBP', 'ACR', 'MDH', 'BKN',
    ),
    membership: derivedMembership(20),
  },
  {
    id: 'east-gem',
    name: 'Eastern Gem & Heritage',
    role: 'Gem cutting and trade, heritage and border commerce — a specialised niche with genuine global standing.',
    provinces: P('CTI', 'TRT', 'SKW', 'PRI'),
    membership: derivedMembership(4),
  },
  {
    id: 'west-minerals',
    name: 'Western Critical Minerals',
    role: 'The upstream end of the recycling and processing bets — critical minerals and rare-earth processing.',
    provinces: P('KRI', 'RBR', 'PBI', 'PKN', 'TAK'),
    membership: derivedMembership(5),
  },
  {
    id: 'central-logistics',
    name: 'Central Plains Logistics',
    role: 'The connector pillar made physical — warehousing, agro-processing and the corridor between Bangkok and the North.',
    provinces: P('AYA', 'SRI', 'LRI', 'SBR', 'ATG', 'CNT', 'SPB', 'NSN', 'NYK', 'UTI'),
    membership: derivedMembership(10),
  },
];

/**
 * Which geography the argument names under each trajectory.
 *
 * Not a province-level score — the papers do not publish one. Each landing
 * points at a named strategic cluster (or at the GPP choropleth) and is the
 * console's reading of where that trajectory's claim sits on the ground.
 * Membership of those clusters is already tiered `derived`.
 */
export interface TrajectoryLanding {
  /** Empty → GPP choropleth. Otherwise the union of these strategic clusters. */
  clusterIds: readonly string[];
  tone: 'gpp' | 'risk' | 'hold';
  kicker: string;
  body: string;
}

export const TRAJECTORY_LANDING: Record<TrajectoryId, TrajectoryLanding> = {
  beta: {
    clusterIds: [],
    tone: 'gpp',
    kicker: 'β · Built for this world',
    body: 'Output concentrates in Bangkok and the Eastern seaboard. The map is the constraint the architecture is designed against — not a picture of it.',
  },
  alpha: {
    clusterIds: ['eec'],
    tone: 'risk',
    kicker: 'α · The exposed geography',
    body: 'Bloc-ification hits the foreign-controlled industrial platform first. The EEC is the highest-value and least sovereign piece of the country at once.',
  },
  gamma: {
    clusterIds: ['bmr', 'north-wellness'],
    tone: 'hold',
    kicker: 'γ · The dividend geography',
    body: 'A reformed concert pays the diplomacy and soft-power layers. Bangkok convenes; the Northern belt is where medical-wellness already scores as sovereign growth.',
  },
  delta: {
    clusterIds: ['isaan'],
    tone: 'hold',
    kicker: 'δ · What still holds',
    body: 'The industrial platform fails. Food sovereignty is what remains — drawn here as Isaan, a quarter to a third of the population on about a tenth of GDP.',
  },
};

/** Sanity: every code above must exist in the province asset. */
export function unknownProvinceCodes(): string[] {
  const bad: string[] = [];
  for (const c of STRATEGIC_CLUSTERS) {
    for (const code of c.provinces) {
      if (!PROVINCE_BY_CODE[code]) bad.push(`${c.id}:${code}`);
    }
  }
  return bad;
}

/**
 * Direct labels on the map — the three regions that carry the argument, plus
 * the two GPP-per-capita poles. Positions are in viewBox units, parked in
 * empty water or the interior of Isaan so they do not sit on the fill.
 * Leader lines run from the named province centroid.
 */
export const MAP_LABELS = [
  {
    region: 'bkk' as RegionId,
    k: 'BMR',
    x: 200,
    y: 800,
    from: 'BKK',
    gdp: REGION_BY_ID.bkk.gdpShare,
    pop: REGION_BY_ID.bkk.popShare,
  },
  {
    region: 'east' as RegionId,
    k: 'EEC',
    x: 680,
    y: 880,
    from: 'CCO',
    gdp: REGION_BY_ID.east.gdpShare,
    pop: REGION_BY_ID.east.popShare,
  },
  {
    region: 'northeast' as RegionId,
    k: 'Isaan',
    x: 760,
    y: 490,
    from: 'KKN',
    gdp: REGION_BY_ID.northeast.gdpShare,
    pop: REGION_BY_ID.northeast.popShare,
  },
] as const;

export const MAP_POLES = [
  { code: 'RYG', name: 'Rayong', x: 620, y: 960, fact: GPP_GAP[0] },
  { code: 'NWT', name: 'Narathiwat', x: 700, y: 1788, fact: GPP_GAP[1] },
] as const;

/** Regions in concentration order — the paired-bar reading. */
export const REGIONS_BY_GDP = [...REGIONS].sort(
  (a, b) => parseShareMid(b.gdpShare.value) - parseShareMid(a.gdpShare.value),
);

export { REGION_OF };
