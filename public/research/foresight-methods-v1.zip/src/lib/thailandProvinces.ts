/**
 * Province geometry adapter.
 *
 * `thailandProvinces.generated.ts` is a generated asset copied verbatim from
 * consulting/nsp-prototype — 77 provinces as pre-projected SVG paths in a
 * 1000×1832 viewBox. It is never hand-edited (§9: never patch generated output;
 * regenerate or adapt around it). This file is the adapter.
 *
 * It does one substantive thing: the asset ships the six-region scheme
 * (BKK/CEN/EST/NTH/NEA/STH), while the Economic Clusters paper reports GPP
 * across seven regions — Bangkok (BMR), Eastern, Northeastern, Northern,
 * Southern, Central excluding BMR, and Western. So Western is split out, and
 * the five BMR provinces are moved out of Central, to make the map agree with
 * the table it sits next to.
 */

import { TH_PROVINCES, TH_VIEWBOX } from './thailandProvinces.generated.ts';

export { TH_VIEWBOX };

export type RegionId =
  | 'bkk'
  | 'east'
  | 'northeast'
  | 'north'
  | 'south'
  | 'central'
  | 'west';

export interface MappedProvince {
  code: string;
  name: string;
  th: string;
  d: string;
  cx: number;
  cy: number;
  region: RegionId;
}

/** Bangkok Metropolitan Region: the capital plus its five contiguous provinces. */
const BMR = new Set(['BKK', 'NBI', 'PTE', 'SPK', 'SKN', 'NPT']);

/**
 * The Western region, per the Royal Institute grouping also used by the
 * NESDB-scheme boundary set in FloodDash (`reg_royin = "West"`). Four provinces
 * come out of Central and Tak comes out of the North.
 */
const WEST = new Set(['KRI', 'RBR', 'PBI', 'PKN', 'TAK']);

const BASE: Record<string, RegionId> = {
  BKK: 'bkk',
  CEN: 'central',
  EST: 'east',
  NTH: 'north',
  NEA: 'northeast',
  STH: 'south',
};

export const PROVINCES: MappedProvince[] = TH_PROVINCES.map((p) => ({
  code: p.code,
  name: p.name,
  th: p.th,
  d: p.d,
  cx: p.cx,
  cy: p.cy,
  region: BMR.has(p.code) ? 'bkk' : WEST.has(p.code) ? 'west' : BASE[p.region],
}));

export const PROVINCE_BY_CODE: Record<string, MappedProvince> =
  Object.fromEntries(PROVINCES.map((p) => [p.code, p]));

export const REGION_OF: Record<string, RegionId> = Object.fromEntries(
  PROVINCES.map((p) => [p.code, p.region]),
);

export const REGION_LABEL: Record<RegionId, string> = {
  bkk: 'Bangkok (BMR)',
  east: 'Eastern (EEC)',
  northeast: 'Northeastern (Isan)',
  north: 'Northern',
  south: 'Southern',
  central: 'Central (excl. BMR)',
  west: 'Western',
};
