/**
 * Score encoding and threshold arithmetic.
 *
 * The paper is explicit that its scores are analytical judgments and that the
 * numeric encoding (High = 3 … Very Low = 0.5) is "a presentation device". Both
 * facts are preserved here: the encoding exists only to place a bubble on a
 * plot, and everything downstream of it is chipped as `judgment`, never as a
 * measurement.
 */

export const SCALE = [
  'Very Low',
  'Low',
  'Low–Med',
  'Med',
  'Med–High',
  'High',
] as const;

export type Score = (typeof SCALE)[number];

/** Growth can also be negative in direction, which is not a point on the scale. */
export type Growth = Score | 'Declining';

/**
 * The author's plotting encoding, extended to the two hyphenated steps by
 * linear interpolation. "Declining" is a direction, not a magnitude; it plots
 * at the floor and is drawn with a downward marker.
 */
const NUMERIC: Record<Growth, number> = {
  'Very Low': 0.5,
  Low: 1,
  'Low–Med': 1.5,
  Med: 2,
  'Med–High': 2.5,
  High: 3,
  Declining: 0.5,
};

export function numeric(s: Growth): number {
  return NUMERIC[s];
}

/** 0…1, used for the amber fill fraction of a score bar. */
export function fraction(s: Growth): number {
  return (numeric(s) - 0.5) / 2.5;
}

export function isDeclining(s: Growth): s is 'Declining' {
  return s === 'Declining';
}

/** One step up the scale. "Declining" recovers to Low. */
export function upgrade(s: Growth): Growth {
  if (s === 'Declining') return 'Low';
  const i = SCALE.indexOf(s);
  return i < 0 || i === SCALE.length - 1 ? s : SCALE[i + 1];
}

// ── Stances ────────────────────────────────────────────────────────────────

export type Stance =
  | 'Keep & upgrade'
  | 'Keep & defend'
  | 'Keep → specialty'
  | 'Focus'
  | 'Focus (conditional)'
  | 'Focus / transition'
  | 'Make it exist';

export type StanceFamily = 'keep' | 'focus' | 'exist';

export function stanceFamily(s: Stance): StanceFamily {
  if (s.startsWith('Focus')) return 'focus';
  if (s.startsWith('Keep')) return 'keep';
  return 'exist';
}

// ── The four review thresholds (Economic Clusters V2, §6.1) ────────────────

export type ThresholdId =
  | 'ev-localisation'
  | 'dc-governance'
  | 'steel-restructure'
  | 'agri-productivity';

export interface Threshold {
  id: ThresholdId;
  /** Which cluster it acts on. */
  cluster: string;
  title: string;
  /** The precondition, close to the paper's own wording. */
  condition: string;
  /** The stated consequence, quoted from §6.1. */
  effect: string;
  /** Applied to the cluster when the switch is on. */
  raise?: 'sovereignty' | 'growth';
  becomes?: Stance;
}

export const THRESHOLDS: Threshold[] = [
  {
    id: 'ev-localisation',
    cluster: 'ev',
    title: 'EV value capture localises',
    condition:
      'Thai-owned Tier-1 EV and battery suppliers, and local cell production, materialise.',
    effect: 'Upgrade the EV sovereignty score and relax conditions.',
    raise: 'sovereignty',
    becomes: 'Focus',
  },
  {
    id: 'dc-governance',
    cluster: 'datacenters',
    title: 'Data centres accept governance terms',
    condition:
      'Operators accept data-residency, local equity, and renewable-power obligations.',
    effect: 'Upgrade the digital sovereignty score.',
    raise: 'sovereignty',
  },
  {
    id: 'steel-restructure',
    cluster: 'steel',
    title: 'Steel restructures upward',
    condition:
      'Steel shifts toward green or specialty output with capacity utilisation above 50%.',
    effect: 'Shift it from "exit" to "keep".',
    becomes: 'Keep & upgrade',
  },
  {
    id: 'agri-productivity',
    cluster: 'food',
    title: 'Agricultural productivity rises',
    condition:
      'Agricultural productivity and future-food exports rise materially.',
    effect:
      'The growth constraint on the highest-sovereignty cluster eases, strengthening the whole rebalancing case.',
    raise: 'growth',
  },
];

// ── Applying them ──────────────────────────────────────────────────────────

export interface Scored {
  value: Score;
  growth: Growth;
  local: Score;
  sovereignty: Score;
  stance: Stance;
}

export interface Adjusted extends Scored {
  /** Which axes moved from the published position, for the UI to mark. */
  moved: Array<'growth' | 'sovereignty' | 'stance'>;
}

/**
 * Pure: (published scores, cluster id, active switches) → adjusted scores.
 *
 * Direction of every change is the paper's. The magnitude — exactly one step on
 * the six-point scale — is this console's convention, because §6.1 states
 * direction without magnitude. That convention is disclosed in the UI.
 *
 * `base` must always be the PUBLISHED scores. Feeding an already-adjusted score
 * back in would ratchet it a second step, which would silently overstate the
 * paper. Callers should use `adjustedCluster()` in data/clusters.ts, which reads
 * the published row itself and makes that mistake unavailable.
 */
export function applyThresholds(
  base: Scored,
  clusterId: string,
  active: ReadonlySet<ThresholdId>,
): Adjusted {
  const out: Adjusted = { ...base, moved: [] };

  for (const t of THRESHOLDS) {
    if (t.cluster !== clusterId || !active.has(t.id)) continue;

    if (t.raise === 'sovereignty') {
      const next = upgrade(out.sovereignty) as Score;
      if (next !== out.sovereignty) {
        out.sovereignty = next;
        out.moved.push('sovereignty');
      }
    }
    if (t.raise === 'growth') {
      const next = upgrade(out.growth);
      if (next !== out.growth) {
        out.growth = next;
        out.moved.push('growth');
      }
    }
    if (t.becomes && t.becomes !== out.stance) {
      out.stance = t.becomes;
      out.moved.push('stance');
    }
  }

  return out;
}
