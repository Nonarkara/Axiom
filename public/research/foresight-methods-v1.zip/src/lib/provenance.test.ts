/**
 * The conservation law, as a runnable check.
 *
 *   Every rendered number equals a sourced claim.
 *   No fact reaches the screen without { value, source, url, tier }.
 *
 * If this fails, the console is asserting something it cannot support — which is
 * the one failure mode that would damage the underlying research rather than
 * merely look bad.
 *
 * Run: npm test
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import { SOURCES, SOURCE_LIST, TIER_MEANING, tierOf } from '../data/sources.ts';
import type { FactRecord, Tier } from '../data/sources.ts';
import { CLUSTERS, adjustedCluster } from '../data/clusters.ts';
import { REGIONS, STRATEGIC_CLUSTERS, GPP_GAP, TRAJECTORY_LANDING, MAP_LABELS, MAP_POLES, parseShareMid, regionIntensity, unknownProvinceCodes } from '../data/geography.ts';
import { PROVINCE_BY_CODE } from '../lib/thailandProvinces.ts';
import { OUTSIDE_CHECK } from '../data/corroboration.ts';
import { LITERATURE, ARGUMENT_COMPONENTS } from '../data/research.ts';
import { PILLARS, STRESS_GRID, ENVELOPE, TRAJECTORIES, COMPARATORS } from '../data/anchor.ts';
import {
  SCALE,
  THRESHOLDS,
  applyThresholds,
  fraction,
  numeric,
  stanceFamily,
  upgrade,
} from './scoring.ts';
import type { Growth, Scored, Stance } from './scoring.ts';

const TIERS: Tier[] = [
  'official',
  'secondary',
  'estimate',
  'projection',
  'judgment',
  'derived',
  'external',
];

/** Every place a number can enter the page. Add a module here when you add one. */
function allFacts(): Array<{ where: string; fact: FactRecord }> {
  const out: Array<{ where: string; fact: FactRecord }> = [];

  for (const c of CLUSTERS) {
    for (const f of c.facts) out.push({ where: `cluster:${c.id}:${f.label}`, fact: f });
  }
  for (const r of REGIONS) {
    out.push({ where: `region:${r.id}:gdp`, fact: r.gdpShare });
    out.push({ where: `region:${r.id}:pop`, fact: r.popShare });
  }
  for (const g of GPP_GAP) out.push({ where: `gpp:${g.label}`, fact: g });
  for (const s of STRATEGIC_CLUSTERS) {
    out.push({ where: `strategic:${s.id}:provinces`, fact: s.membership });
  }
  for (const e of ENVELOPE.rows) {
    out.push({ where: `envelope:${e.layer}:capital`, fact: e.capital });
    out.push({ where: `envelope:${e.layer}:gdp`, fact: e.ofGdp });
  }
  for (const t of TRAJECTORIES) out.push({ where: `trajectory:${t.id}`, fact: t.likelihood });
  for (const g of OUTSIDE_CHECK) {
    for (const f of g.facts) out.push({ where: `outside:${g.id}:${f.label}`, fact: f });
  }

  return out;
}

test('outside-check figures never borrow the papers\' authority', () => {
  // Corroboration the console added must stay visibly external (or an explicit
  // projection) — never chipped as the author's own evidence base.
  for (const g of OUTSIDE_CHECK) {
    for (const f of g.facts) {
      const t = tierOf(f);
      assert.ok(
        t === 'external' || t === 'projection',
        `outside:${g.id}:${f.label}: tier "${t}" would blur console corroboration into the papers' evidence`,
      );
    }
    assert.ok(g.reading.length > 0 && g.paperClaim.length > 0, `${g.id}: missing reading`);
  }
});

test('literature-check citations never borrow the papers\' authority', () => {
  // Studies this console added must stay visibly external — never chipped as
  // the author's own evidence base. The verdicts/matrix carry no numbers, so
  // the conservation law is untouched; this keeps even that boundary honest.
  for (const s of LITERATURE) {
    const src = SOURCES[s.src];
    assert.ok(src, `literature:${s.id}: unknown source "${s.src}"`);
    assert.equal(
      src.tier,
      'external',
      `literature:${s.id}: must be tiered "external"`,
    );
    assert.ok(s.finding.trim().length > 0, `${s.id}: no finding stated`);
    assert.ok(s.analysis.trim().length > 0, `${s.id}: no analysis stated`);
    assert.ok(
      ['supports', 'extends', 'complicates'].includes(s.verdict),
      `${s.id}: unknown verdict "${s.verdict}"`,
    );
    // Every glyph in the matrix must point at a declared component.
    const ids = ARGUMENT_COMPONENTS.map((c) => c.id as string);
    for (const key of Object.keys(s.speaks)) {
      assert.ok(
        ids.includes(key),
        `${s.id}: glyph column "${key}" is not a declared argument component`,
      );
      assert.ok(
        s.speaks[key as keyof typeof s.speaks] === 'direct' ||
          s.speaks[key as keyof typeof s.speaks] === 'partial',
        `${s.id}:${key}: glyph must be direct or partial`,
      );
    }
    // A study with no glyph speaks to nothing — a row of blanks.
    assert.ok(
      Object.keys(s.speaks).length > 0,
      `${s.id}: the matrix row is empty`,
    );
  }
});

test('literature verdict counts add up to the register size', () => {
  // The §10 filter bar reads the counts off the register; if any verdict's
  // count drifts from the actual LITERATURE length, the filter chips mislead.
  const counts = { supports: 0, extends: 0, complicates: 0 };
  for (const s of LITERATURE) counts[s.verdict] += 1;
  assert.equal(
    counts.supports + counts.extends + counts.complicates,
    LITERATURE.length,
    'verdict counts do not add up to the register size',
  );
  // At least one study should complicate the argument — otherwise the page
  // claims to register disagreement while in fact registering none.
  assert.ok(counts.complicates > 0, 'no study complicates the argument');
});

test('every literature study carries a geography tag (or it is silently dropped from the cross-analysis)', () => {
  // The cross-analysis at the foot of §10 reads each study's geography field.
  // A study with no geography is silently dropped from the region grid — fine,
  // but it is a missed opportunity, and the register should be honest about it.
  const untagged = LITERATURE.filter((s) => !s.geography || s.geography.length === 0);
  if (untagged.length > 0) {
    assert.fail(
      `studies missing geography tags: ${untagged.map((s) => s.id).join(', ')}`,
    );
  }
  // Every region in any tag must be a real RegionId.
  for (const s of LITERATURE) {
    for (const r of s.geography ?? []) {
      assert.ok(
        ['bkk', 'east', 'northeast', 'north', 'south', 'central', 'west'].includes(r),
        `${s.id}: unknown region "${r}"`,
      );
    }
  }
  // The Bangkok count should be high; the Isaan count should be at least 1.
  // If either drifts, the cross-analysis's footer note ("BKK is the most-studied,
  // Isaan the most-underserved") would be lying.
  const bkk = LITERATURE.filter((s) => s.geography?.includes('bkk')).length;
  const isaan = LITERATURE.filter((s) => s.geography?.includes('northeast')).length;
  assert.ok(bkk >= 3, `only ${bkk} study speaks to BKK — page claims ≥3`);
  assert.ok(isaan >= 1, `no study speaks to Isaan — page claims ≥1`);
});

test('every fact names a source that exists', () => {
  for (const { where, fact } of allFacts()) {
    assert.ok(fact.value.trim().length > 0, `${where}: empty value`);
    assert.ok(SOURCES[fact.src], `${where}: unknown source "${fact.src}"`);
  }
});

test('every fact resolves to a declared tier', () => {
  for (const { where, fact } of allFacts()) {
    const tier = tierOf(fact);
    assert.ok(TIERS.includes(tier), `${where}: tier "${tier}" is not in the vocabulary`);
    assert.ok(TIER_MEANING[tier], `${where}: tier "${tier}" has no reader-facing meaning`);
  }
});

test('every source carries a resolvable https URL and a label', () => {
  for (const s of SOURCE_LIST) {
    assert.ok(s.label.trim().length > 0, `${s.id}: no label`);
    assert.match(s.url, /^https:\/\/\S+$/, `${s.id}: not an https URL`);
    assert.ok(TIERS.includes(s.tier), `${s.id}: bad tier`);
  }
});

test('the source register has no duplicate ids', () => {
  const ids = SOURCE_LIST.map((s) => s.id);
  assert.equal(new Set(ids).size, ids.length, 'duplicate source id');
});

test('anything the console added, not the papers, is tiered "derived"', () => {
  // The province membership of the nine strategic clusters is the one thing this
  // console authors. It must never be able to masquerade as sourced.
  for (const s of STRATEGIC_CLUSTERS) {
    assert.equal(
      tierOf(s.membership),
      'derived',
      `${s.id}: province membership must be tiered "derived"`,
    );
    assert.ok(s.provinces.length > 0, `${s.id}: no provinces mapped`);
  }
});

// ── Scores ────────────────────────────────────────────────────────────────

const STANCES: Stance[] = [
  'Keep & upgrade',
  'Keep & defend',
  'Keep → specialty',
  'Focus',
  'Focus (conditional)',
  'Focus / transition',
  'Make it exist',
];

test('every cluster score sits on the published scale', () => {
  for (const c of CLUSTERS) {
    for (const axis of ['value', 'local', 'sovereignty'] as const) {
      assert.ok(
        (SCALE as readonly string[]).includes(c[axis]),
        `${c.id}.${axis} = "${c[axis]}" is off-scale`,
      );
    }
    const growthOk =
      (SCALE as readonly string[]).includes(c.growth) || c.growth === 'Declining';
    assert.ok(growthOk, `${c.id}.growth = "${c.growth}" is off-scale`);
    assert.ok(STANCES.includes(c.stance), `${c.id}: unknown stance "${c.stance}"`);
    assert.ok(['keep', 'focus', 'exist'].includes(stanceFamily(c.stance)));
  }
});

test('the plotting encoding stays inside the plot', () => {
  const every: Growth[] = [...SCALE, 'Declining'];
  for (const s of every) {
    const f = fraction(s);
    assert.ok(f >= 0 && f <= 1, `fraction("${s}") = ${f} is outside 0…1`);
    assert.ok(numeric(s) >= 0.5 && numeric(s) <= 3, `numeric("${s}") off the author's 0.5…3 range`);
  }
});

test('upgrade moves exactly one step and stops at the ceiling', () => {
  assert.equal(upgrade('Very Low'), 'Low');
  assert.equal(upgrade('Low'), 'Low–Med');
  assert.equal(upgrade('Med'), 'Med–High');
  assert.equal(upgrade('High'), 'High', 'must not run past the top of the scale');
  assert.equal(upgrade('Declining'), 'Low', 'a declining cluster recovers onto the scale');
});

// ── Thresholds ────────────────────────────────────────────────────────────

test('every threshold points at a cluster that exists', () => {
  for (const t of THRESHOLDS) {
    assert.ok(
      CLUSTERS.some((c) => c.id === t.cluster),
      `threshold ${t.id} targets unknown cluster "${t.cluster}"`,
    );
    assert.ok(t.condition.trim().length > 0, `${t.id}: no stated precondition`);
    assert.ok(t.effect.trim().length > 0, `${t.id}: no stated effect`);
  }
});

const base = (id: string): Scored => {
  const c = CLUSTERS.find((x) => x.id === id)!;
  return {
    value: c.value,
    growth: c.growth,
    local: c.local,
    sovereignty: c.sovereignty,
    stance: c.stance,
  };
};

test('with no switches thrown, nothing moves', () => {
  for (const c of CLUSTERS) {
    const out = applyThresholds(base(c.id), c.id, new Set());
    assert.deepEqual({ ...out, moved: undefined }, { ...base(c.id), moved: undefined });
    assert.equal(out.moved.length, 0);
  }
});

test('a threshold moves only its own cluster', () => {
  const active = new Set(['ev-localisation' as const]);
  for (const c of CLUSTERS) {
    const out = applyThresholds(base(c.id), c.id, active);
    if (c.id === 'ev') assert.ok(out.moved.length > 0, 'EV should move');
    else assert.equal(out.moved.length, 0, `${c.id} moved on someone else's threshold`);
  }
});

test('each threshold produces exactly the effect §6.1 states', () => {
  // EV: "upgrade the EV sovereignty score and relax conditions"
  const ev = applyThresholds(base('ev'), 'ev', new Set(['ev-localisation']));
  assert.equal(ev.sovereignty, 'Low–Med');
  assert.equal(ev.stance, 'Focus');

  // Data centres: "upgrade the digital sovereignty score" — and nothing else.
  const dc = applyThresholds(base('datacenters'), 'datacenters', new Set(['dc-governance']));
  assert.equal(dc.sovereignty, 'Low');
  assert.equal(dc.stance, 'Focus (conditional)', 'the paper does not relax the DC stance');

  // Steel: "shift it from exit to keep" — stance only, no score change.
  const steel = applyThresholds(base('steel'), 'steel', new Set(['steel-restructure']));
  assert.equal(steel.stance, 'Keep & upgrade');
  assert.equal(steel.growth, 'Declining', 'the paper does not restore steel growth');
  assert.equal(steel.sovereignty, 'Low');

  // Food: "the growth constraint … eases" — growth only.
  const food = applyThresholds(base('food'), 'food', new Set(['agri-productivity']));
  assert.equal(food.growth, 'Med');
  assert.equal(food.stance, 'Keep & upgrade');
});

test('re-reading a cluster never ratchets its score a second step', () => {
  // adjustedCluster() resolves the published row itself, so repeated reads —
  // which is exactly what a re-render is — must always land on the same value.
  for (const t of THRESHOLDS) {
    const active = new Set([t.id]);
    const first = adjustedCluster(t.cluster, active);
    const second = adjustedCluster(t.cluster, active);
    assert.deepEqual(
      second.sovereignty,
      first.sovereignty,
      `${t.id}: sovereignty ratcheted on a re-read`,
    );
    assert.deepEqual(second.growth, first.growth, `${t.id}: growth ratcheted on a re-read`);
    assert.equal(second.stance, first.stance);
    // And one step is one step, not two.
    assert.ok(first.moved.length <= 2, `${t.id} moved more axes than §6.1 states`);
  }
});

test('turning every switch on moves each cluster at most one step per axis', () => {
  const all = new Set(THRESHOLDS.map((t) => t.id));
  for (const c of CLUSTERS) {
    const adj = adjustedCluster(c.id, all);
    for (const axis of ['sovereignty', 'growth'] as const) {
      const from = SCALE.indexOf(c[axis] as never);
      const to = SCALE.indexOf(adj[axis] as never);
      if (from >= 0 && to >= 0) {
        assert.ok(to - from <= 1, `${c.id}.${axis} moved ${to - from} steps; §6.1 states one`);
      }
    }
  }
});

test('applyThresholds does not mutate its input', () => {
  const input = base('ev');
  const snapshot = { ...input };
  applyThresholds(input, 'ev', new Set(['ev-localisation']));
  assert.deepEqual(input, snapshot);
});

// ── Anchor Strategy layer ─────────────────────────────────────────────────

test('the stress grid is complete and inside the published 0–10 range', () => {
  const trajIds = TRAJECTORIES.map((t) => t.id);
  for (const row of STRESS_GRID) {
    for (const id of trajIds) {
      const v = row.scores[id];
      assert.equal(typeof v, 'number', `${row.layer} has no score for ${id}`);
      assert.ok(v >= 0 && v <= 10, `${row.layer}/${id} = ${v} is outside 0–10`);
    }
    // The paper prints a mean per row; recompute it rather than trusting the copy.
    const mean =
      trajIds.reduce((a, id) => a + row.scores[id], 0) / trajIds.length;
    assert.ok(
      Math.abs(mean - row.mean) < 0.06,
      `${row.layer}: printed mean ${row.mean} does not match computed ${mean.toFixed(2)}`,
    );
  }
});

test('the stress grid covers every pillar plus the Foundation', () => {
  assert.equal(STRESS_GRID.length, PILLARS.length + 1);
  for (const p of PILLARS) {
    assert.ok(
      STRESS_GRID.some((r) => r.layer === p.name),
      `${p.name} is missing from the stress grid`,
    );
  }
});

test('the Sovereign Foundation is the only layer that peaks under cascade', () => {
  // This is the strategy's central structural claim; if the data ever stops
  // saying it, the console would be arguing something the paper does not.
  const delta = STRESS_GRID.map((r) => ({ layer: r.layer, d: r.scores.delta }));
  const top = Math.max(...delta.map((x) => x.d));
  const winners = delta.filter((x) => x.d === top);
  assert.equal(winners.length, 1);
  assert.match(winners[0].layer, /Sovereign Foundation/);
});

test('trajectory landings name real strategic clusters', () => {
  assert.equal(unknownProvinceCodes().length, 0);
  for (const id of TRAJECTORIES.map((t) => t.id)) {
    const land = TRAJECTORY_LANDING[id];
    assert.ok(land, `missing landing for ${id}`);
    for (const cid of land.clusterIds) {
      assert.ok(
        STRATEGIC_CLUSTERS.some((c) => c.id === cid),
        `${id} lands on unknown cluster ${cid}`,
      );
    }
  }
  assert.equal(TRAJECTORY_LANDING.alpha.tone, 'risk');
  assert.deepEqual([...TRAJECTORY_LANDING.alpha.clusterIds], ['eec']);
  assert.equal(TRAJECTORY_LANDING.delta.tone, 'hold');
  assert.deepEqual([...TRAJECTORY_LANDING.delta.clusterIds], ['isaan']);
  assert.equal(TRAJECTORY_LANDING.beta.clusterIds.length, 0);
});

test('share parsing and map annotations stay on sourced geography', () => {
  assert.equal(parseShareMid('~47–48%'), 47.5);
  assert.equal(parseShareMid('~24%'), 24);
  assert.equal(parseShareMid('~9–11.5%'), 10.25);
  assert.equal(regionIntensity('bkk'), 47.5 / 48);
  assert.ok(regionIntensity('northeast') < regionIntensity('east'));
  assert.ok(regionIntensity('east') < regionIntensity('bkk'));

  for (const lab of MAP_LABELS) {
    assert.ok(PROVINCE_BY_CODE[lab.from], `label ${lab.k} points at unknown ${lab.from}`);
  }
  for (const pole of MAP_POLES) {
    assert.ok(PROVINCE_BY_CODE[pole.code], `pole ${pole.name} points at unknown ${pole.code}`);
  }
  assert.equal(MAP_POLES[0].fact, GPP_GAP[0]);
  assert.equal(MAP_POLES[1].fact, GPP_GAP[1]);
  assert.equal(REGIONS[0].id, 'bkk');
});

test('the four comparator anchors each carry a distinct lesson', () => {
  assert.equal(COMPARATORS.length, 4);
  const lessons = COMPARATORS.map((c) => c.lesson);
  assert.equal(new Set(lessons).size, 4);
  for (const c of COMPARATORS) {
    assert.ok(c.takes.length > 0, `${c.name}: nothing Thailand can take`);
    assert.ok(c.doesNotTransfer.length > 0, `${c.name}: no stated limits — that reads as a template`);
  }
});
