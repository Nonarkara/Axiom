# Foresight Methods Supplement v1

Preprint - not peer-reviewed. Research: Poon Thiengburanathum. Analysis: Non Arkaraprasertkul.

With Node.js 22.13 or later (native TypeScript stripping):

    node --experimental-strip-types analysis.mjs --snapshot . --out reproduced.json

Compare reproduced.json with results.json. The snapshot contains only the eleven pinned
source files needed by the audit, not the private Git repository, application secrets,
or the unavailable full source reports. snapshot-manifest.json records their hashes.

The source pin is 459d79c585d8c67830bd492ebe791429824f1024. Results describe encoded rules, not policy
effects or calibrated forecasts. primary-checks.json captures selected later statistical
responses; differences do not establish errors at the original publication vintage.

Provided as inspection material for this owner-requested preprint. No blanket licence
to third-party statistics, reports or referenced publications is asserted. Consult their
original sources and terms. Province SVG geometry derives from apisit/thailand.json;
its MIT notice and copyright are preserved in UPSTREAM-thailand-README.md.
